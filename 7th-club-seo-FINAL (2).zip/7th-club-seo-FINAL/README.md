# 7th Club SEO Analyzer Pro v2.0

**Professional Chrome Extension — White Label SEO Analysis Tool**
*Built & branded by [7thclub.com](https://7thclub.com)*

---

## ✨ What's New in v2

- **Complete white/light theme** — clean, professional design matching 7th Club brand
- **SERP Preview Tab** — see exactly how Google shows your page on Desktop & Mobile
- **Character counters** with color-coded progress bars (Title, Description, OG)
- **Advanced link analysis** — dofollow/nofollow/sponsored/ugc/new-tab detection
- **Performance metrics** — TTFB, DOM Content Loaded, Total Load Time
- **Internationalization** — hreflang tag detection
- **Image deep-dive** — srcset, lazy load, alt filter views
- **Technical groups** — Security, Basics, Content, Performance, i18n, Social
- **SEO Score Ring** — animated 0–100 score with color grading
- **Grade Pills** — instant visual pass/fail for all key signals
- **Quick Fixes panel** — prioritized list of issues to fix

---

## 📊 7 Analysis Tabs

| Tab | What You Get |
|-----|-------------|
| **Overview** | SEO score, grade pills, metric cards, quick fixes |
| **SERP** | Desktop + mobile Google preview, char counters |
| **Meta** | Basic, Open Graph, Twitter Card, all meta tags |
| **Headings** | H1–H6 hierarchy tree with structural alerts |
| **Links** | Internal/External/Nofollow with rel attribute details |
| **Images** | Alt text checker, lazy load, srcset analysis |
| **Technical** | 6 grouped sections: security, performance, i18n & more |

---

## 🚀 Installation

1. Download and **unzip** the ZIP file
2. Open Chrome → `chrome://extensions/`
3. Toggle **Developer mode** ON (top-right)
4. Click **"Load unpacked"**
5. Select the `seo-ext-v2` folder
6. Pin the extension to your toolbar 📌

---

## 📁 File Structure

```
seo-ext-v2/
├── manifest.json        # Manifest V3 config
├── popup.html           # Main popup UI
├── css/
│   └── popup.css        # White theme (Plus Jakarta Sans + JetBrains Mono)
├── js/
│   ├── popup.js         # All UI logic (800+ lines)
│   ├── content.js       # Page SEO data collector
│   └── background.js    # Service worker
└── icons/
    ├── icon16.png
    ├── icon32.png
    ├── icon48.png
    └── icon128.png
```

---

## 🎯 SEO Score Calculation

| Check                    | Points |
|--------------------------|--------|
| Title 30–60 chars        | ±15    |
| Description 70–160 chars | ±10    |
| Exactly 1 H1             | ±10    |
| HTTPS                    | ±10    |
| Not noindexed            | ±15    |
| Viewport meta            | ±4     |
| Canonical URL            | ±5     |
| Open Graph tags          | ±4     |
| Image alt text           | ±8     |
| Twitter Card             | ±2     |
| Structured data          | ±3     |
| Word count ≥ 300         | ±3     |

**Green ≥ 80 · Yellow ≥ 60 · Red < 60**

---

## 🌐 Brand

**7th Club** — White Label SEO & Digital Marketing Agency  
Website: https://7thclub.com  
Email: contact@7thclub.com
