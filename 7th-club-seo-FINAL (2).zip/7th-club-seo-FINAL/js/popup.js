'use strict';
const $ = id => document.getElementById(id);
const el = (tag, cls) => { const e = document.createElement(tag); if(cls) e.className=cls; return e; };
const esc = s => String(s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
const clamp = (v,mn,mx) => Math.min(mx,Math.max(mn,v));

/* ── Score Calc ── */
function calcScore(d){
  let score=100; const issues=[];
  const tl=d.titleTag.length;
  if(!d.titleTag){score-=15;issues.push({sev:'error',text:'Title tag is missing'});}
  else if(tl<30){score-=6;issues.push({sev:'warn',text:`Title too short (${tl} chars, aim 30–60)`});}
  else if(tl>60){score-=4;issues.push({sev:'warn',text:`Title too long (${tl} chars, aim 30–60)`});}
  const dl=d.description.length;
  if(!d.description){score-=10;issues.push({sev:'error',text:'Meta description missing'});}
  else if(dl<70){score-=4;issues.push({sev:'warn',text:`Description too short (${dl} chars)`});}
  else if(dl>160){score-=3;issues.push({sev:'warn',text:`Description too long (${dl} chars, aim ≤160)`});}
  if(d.h1Count===0){score-=10;issues.push({sev:'error',text:'No H1 heading found'});}
  else if(d.h1Count>1){score-=5;issues.push({sev:'warn',text:`Multiple H1 tags (${d.h1Count})`});}
  if(!d.isHttps){score-=10;issues.push({sev:'error',text:'Page not served over HTTPS'});}
  if(!d.canonical){score-=5;issues.push({sev:'warn',text:'No canonical URL defined'});}
  if(!d.lang){score-=3;issues.push({sev:'warn',text:'Missing lang attribute on <html>'});}
  if(!d.viewport){score-=4;issues.push({sev:'error',text:'Missing viewport meta tag (not mobile-friendly)'});}
  if(d.isNoindex){score-=15;issues.push({sev:'error',text:'Page is set to noindex — will not rank'});}
  if(d.imagesMissing>0){score-=Math.min(8,d.imagesMissing*2);issues.push({sev:'warn',text:`${d.imagesMissing} image(s) missing alt text`});}
  const ogKeys=Object.keys(d.openGraph).length;
  if(ogKeys===0){score-=4;issues.push({sev:'warn',text:'No Open Graph tags found'});}
  else if(!d.openGraph['og:image']){score-=2;issues.push({sev:'warn',text:'Missing og:image tag'});}
  if(!d.twitter['twitter:card']){score-=2;issues.push({sev:'warn',text:'Missing Twitter Card tags'});}
  if(d.structuredData.length===0){score-=3;issues.push({sev:'warn',text:'No structured data (JSON-LD) found'});}
  if(d.wordCount<300){score-=3;issues.push({sev:'warn',text:`Low word count (${d.wordCount} words)`});}
  return {score:clamp(Math.round(score),0,100),issues};
}

function scoreColor(s){if(s>=80)return'#3B5DD4';if(s>=60)return'#FEB622';return'#ef4444';}

function animateScore(score){
  const prog=$('scProg'),num=$('scoreNum'),circ=207.3;
  const offset=circ-(score/100)*circ,color=scoreColor(score);
  prog.style.stroke=color; prog.style.strokeDashoffset=offset;
  prog.style.filter=`drop-shadow(0 0 5px ${color}66)`;
  num.textContent=score; num.style.color=color;
}

/* ── Keyword Density ── */
function calcKeywordDensity(text,wordCount){
  const stopWords=new Set(['the','a','an','and','or','but','in','on','at','to','for','of','with','by','from','is','was','are','were','be','been','being','have','has','had','do','does','did','will','would','could','should','may','might','shall','can','this','that','these','those','it','its','i','we','you','he','she','they','my','our','your','his','her','their','all','as','if','so','not','no','yet','also','more','some','any','than','then','when','where','who','which','how','what','there','here','just','only','even','about','up','out','after','before','into','over','under','through','between','while','us','them','each','both','such','much','very','too','other','new','first','last','one','two','three','like','get','make','use','go','see','know','take','come','think','look','want','give','need','find','tell','ask','seem','feel','try','leave','call']);
  const words=text.toLowerCase().replace(/[^a-z\s]/g,' ').split(/\s+/).filter(w=>w.length>3&&!stopWords.has(w));
  const freq={};
  words.forEach(w=>{freq[w]=(freq[w]||0)+1;});
  return Object.entries(freq).sort((a,b)=>b[1]-a[1]).slice(0,15).map(([word,count])=>({word,count,density:((count/wordCount)*100).toFixed(2)}));
}

/* ── Tech Health Score ── */
function calcTechHealth(d){
  let score=100;
  if(!d.isHttps)score-=20;
  if(!d.canonical)score-=10;
  if(!d.viewport)score-=15;
  if(!d.lang)score-=5;
  if(d.isNoindex)score-=20;
  if(!d.favicon)score-=5;
  if(d.doctype!=='HTML')score-=5;
  if(!d.charset)score-=5;
  if(d.structuredData.length===0)score-=10;
  if(d.hreflangs&&d.hreflangs.length===0&&d.lang)score+=0;
  return Math.max(0,Math.round(score))+'%';
}

/* ─── RENDER: Overview ─── */
let _seoData=null;
function renderOverview(d,score,issues){
  _seoData=d;
  const errors=issues.filter(i=>i.sev==='error').length;
  const warns=issues.filter(i=>i.sev==='warn').length;
  const passed=Object.keys({title:d.titleTag,desc:d.description,h1:d.h1Count===1,https:d.isHttps,canonical:d.canonical,lang:d.lang,viewport:d.viewport,noindex:!d.isNoindex,og:Object.keys(d.openGraph).length,tw:d.twitter['twitter:card'],schema:d.structuredData.length,wc:d.wordCount>=300}).filter(k=>{const v={title:!!d.titleTag,desc:!!d.description,h1:d.h1Count===1,https:d.isHttps,canonical:!!d.canonical,lang:!!d.lang,viewport:!!d.viewport,noindex:!d.isNoindex,og:Object.keys(d.openGraph).length>0,tw:!!d.twitter['twitter:card'],schema:d.structuredData.length>0,wc:d.wordCount>=300};return v[k];}).length;
  if($('errCount'))$('errCount').textContent=errors;
  if($('warnCount'))$('warnCount').textContent=warns;
  if($('passCount'))$('passCount').textContent=passed;
  if(issues.length>0){$('issuesBanner').classList.remove('hidden');$('issuesBannerText').textContent=`${errors} error${errors!==1?'s':''}, ${warns} warning${warns!==1?'s':''} found`;}
  const gradeRow=$('gradeRow'); if(gradeRow)gradeRow.innerHTML='';
  const grid=$('cardsGrid'); if(grid)grid.innerHTML='';
  const tl=d.titleTag.length,dl=d.description.length;

  // Overview rows
  const op=d.overview||{};
  const tvEl=$('titleVal'),tbEl=$('titleBadge');
  if(tvEl){tvEl.textContent=d.titleTag||(op.titleVal||'Not set');tvEl.className='seo-row-val'+((!d.titleTag)?' missing':'');}
  if(tbEl){const s=!d.titleTag?'error':(tl>=30&&tl<=60?'ok':'warn');tbEl.innerHTML=`<span class="badge-pill ${s}">${!d.titleTag?'Missing':tl>=30&&tl<=60?`${tl} chars ✓`:'Too '+(tl<30?'Short':'Long')}</span>`;}
  // Add color class to title row
  const titleRow=tbEl?tbEl.closest('.seo-row'):null;
  if(titleRow){const s=!d.titleTag?'error':(tl>=30&&tl<=60?'ok':'warn');titleRow.classList.remove('row-ok','row-warn','row-error');titleRow.classList.add('row-'+s);}
  const dvEl=$('descVal'),dbEl=$('descBadge');
  if(dvEl){dvEl.textContent=d.description?d.description.substring(0,80)+(dl>80?'…':''):'Not set';dvEl.className='seo-row-val'+((!d.description)?' missing':'');}
  if(dbEl){const s=!d.description?'error':(dl>=70&&dl<=160?'ok':'warn');dbEl.innerHTML=`<span class="badge-pill ${s}">${!d.description?'Missing':dl>=70&&dl<=160?`${dl} chars ✓`:'Too '+(dl<70?'Short':'Long')}</span>`;}
  // Add color class to desc row
  const descRow=dbEl?dbEl.closest('.seo-row'):null;
  if(descRow){const s=!d.description?'error':(dl>=70&&dl<=160?'ok':'warn');descRow.classList.remove('row-ok','row-warn','row-error');descRow.classList.add('row-'+s);}
  if($('urlVal'))$('urlVal').textContent=d.url||'';
  if($('indexBadge')){const s=d.isNoindex?'error':'ok';$('indexBadge').innerHTML=`<span class="badge-pill ${s}">${d.isNoindex?'Noindex':'Indexed'}</span>`;const idxRow=$('indexBadge').closest('.seo-row');if(idxRow){idxRow.classList.remove('row-ok','row-warn','row-error');idxRow.classList.add('row-'+(d.isNoindex?'error':'ok'));}}
  if($('canonicalVal')){$('canonicalVal').textContent=d.canonical||'Not set';const canRow=$('canonicalVal').closest('.seo-row');if(canRow){canRow.classList.remove('row-ok','row-warn','row-error');canRow.classList.add('row-'+(d.canonical?'ok':'warn'));}}
  if($('robotsVal')){$('robotsVal').textContent=d.robots||'index, follow (default)';const rRow=$('robotsVal').closest('.seo-row');if(rRow){rRow.classList.remove('row-ok','row-warn','row-error');rRow.classList.add(d.isNoindex?'row-error':'row-ok');}}
  if($('kwVal'))$('kwVal').textContent=d.keywords||'(not set)';
  if($('wcVal')){$('wcVal').textContent=`${d.wordCount.toLocaleString()} words`;const wcRow=$('wcVal').closest('.seo-row');if(wcRow){wcRow.classList.remove('row-ok','row-warn','row-error');wcRow.classList.add(d.wordCount>=300?'row-ok':'row-warn');}}
  if($('langVal')){$('langVal').textContent=d.lang||'Not set';const lRow=$('langVal').closest('.seo-row');if(lRow){lRow.classList.remove('row-ok','row-warn','row-error');lRow.classList.add(d.lang?'row-ok':'row-warn');}}
  const counts={1:0,2:0,3:0,4:0};
  d.headings.forEach(h=>{if(counts[h.level]!==undefined)counts[h.level]++;});
  ['h1c','h2c','h3c','h4c'].forEach((id,i)=>{if($(id))$(id).textContent=counts[i+1];});
  if($('imgC'))$('imgC').textContent=d.images.length;
  if($('linkC'))$('linkC').textContent=d.links.length;
  const host=d.host||'';
  if($('qlRobots'))$('qlRobots').href=`https://${host}/robots.txt`;
  if($('qlSitemap'))$('qlSitemap').href=`https://${host}/sitemap.xml`;

  // Quick fixes
  if(issues.length>0){
    $('fixesBlock').classList.remove('hidden');
    const list=$('fixesList'); list.innerHTML='';
    issues.slice(0,8).forEach(issue=>{
      const li=el('li',`fb-item ${issue.sev}`);
      li.innerHTML=`<span class="fi-dot">${issue.sev==='error'?'❌':'⚠️'}</span><span>${esc(issue.text)}</span>`;
      list.appendChild(li);
    });
  }

  // Score grade
  const sg=$('scoreGrade');
  if(sg){const g=score>=90?'Excellent':score>=80?'Good':score>=60?'Needs Work':'Poor';sg.textContent=g;sg.className='score-grade '+(score>=80?'ok':score>=60?'warn':'error');}

  // Keyword Density
  const kd=calcKeywordDensity(document.body?'':d.bodyText||'',d.wordCount);
  renderKeywordDensity(d);

  // Tech health
  const th=calcTechHealth(d);
  if($('saTechScore'))$('saTechScore').textContent=th;
}

function renderKeywordDensity(d){
  const kd=calcKeywordDensity(d.bodyText||'',Math.max(d.wordCount,1));
  const mini=$('kdMiniList');
  if(mini){mini.innerHTML='';kd.slice(0,5).forEach(k=>{const r=el('div','kd-mini-row');r.innerHTML=`<span class="kd-mini-word">${esc(k.word)}</span><span class="kd-mini-pct">${k.density}%</span>`;mini.appendChild(r);});}
  const full=$('kdList');
  if(full){
    full.innerHTML='';
    if($('kdWordBadge'))$('kdWordBadge').textContent=`${d.wordCount.toLocaleString()} words`;
    kd.forEach((k,i)=>{
      const pct=Math.min(100,(k.count/Math.max(kd[0].count,1))*100);
      const row=el('div','kd-row');
      row.innerHTML=`<span class="kd-rank">${i+1}</span><div class="kd-word-wrap"><span class="kd-word">${esc(k.word)}</span><div class="kd-bar-wrap"><div class="kd-bar" style="width:${pct}%"></div></div></div><span class="kd-count">${k.count}×</span><span class="kd-pct ${parseFloat(k.density)>4?'high':parseFloat(k.density)>2?'mid':'low'}">${k.density}%</span>`;
      full.appendChild(row);
    });
  }
}

/* ─── RENDER: Page Speed ─── */
function renderPageSpeed(d){
  const ttfb=d.ttfb, dcl=d.domContentLoaded, lt=d.loadTime;
  let speedScore=100;
  if(ttfb!=null){if(ttfb>600)speedScore-=30;else if(ttfb>200)speedScore-=15;}
  if(dcl!=null){if(dcl>3000)speedScore-=25;else if(dcl>1500)speedScore-=12;}
  if(lt!=null){if(lt>6000)speedScore-=25;else if(lt>3000)speedScore-=12;}
  if(d.imagesMissing>5)speedScore-=5;
  if(d.imagesLazy===0&&d.images.length>3)speedScore-=5;
  speedScore=Math.max(0,Math.min(100,speedScore));

  const prog=$('psProg'),num=$('psScoreNum');
  if(prog&&num){
    const circ=207.3,offset=circ-(speedScore/100)*circ,color=speedScore>=80?'#3B5DD4':speedScore>=50?'#FEB622':'#ef4444';
    prog.style.stroke=color; prog.style.strokeDashoffset=offset;
    prog.style.filter=`drop-shadow(0 0 5px ${color}66)`;
    num.textContent=speedScore; num.style.color=color;
  }
  const lbl=$('psScoreLabel');
  if(lbl)lbl.textContent=speedScore>=80?'Fast':speedScore>=50?'Needs Improvement':'Slow';

  const metrics=$('psMetrics');
  if(metrics){
    metrics.innerHTML='';
    const rows=[
      {label:'TTFB',val:ttfb!=null?`${ttfb}ms`:null,good:200,warn:600,unit:'ms'},
      {label:'DOM Ready',val:dcl!=null?`${dcl}ms`:null,good:1500,warn:3000,unit:'ms'},
      {label:'Load Time',val:lt!=null?`${lt}ms`:null,good:3000,warn:6000,unit:'ms'},
      {label:'Scripts',val:d.scriptCount!=null?d.scriptCount:null,good:20,warn:40,unit:''},
      {label:'Stylesheets',val:d.styleCount!=null?d.styleCount:null,good:5,warn:10,unit:''},
    ];
    rows.forEach(r=>{
      const raw=r.val!=null?parseInt(r.val):null;
      const cls=raw==null?'neutral':raw<=r.good?'ok':raw<=r.warn?'warn':'error';
      const div=el('div','ps-metric-row');
      div.innerHTML=`<span class="ps-m-label">${r.label}</span><span class="ps-m-val ${cls}">${r.val!=null?r.val:'N/A'}</span>`;
      metrics.appendChild(div);
    });
  }

  // CWV
  const cwv=$('psCwvGrid');
  if(cwv){
    cwv.innerHTML='';
    const items=[
      {label:'LCP (est.)',desc:'Largest Contentful Paint',val:lt!=null?`~${lt}ms`:null,target:'< 2500ms',cls:lt!=null?lt<2500?'ok':lt<4000?'warn':'error':'neutral'},
      {label:'FID / INP',desc:'Interaction to Next Paint',val:'Browser Only',target:'< 200ms',cls:'neutral'},
      {label:'CLS',desc:'Cumulative Layout Shift',val:'Run PSI',target:'< 0.1',cls:'neutral'},
      {label:'TTFB',desc:'Time to First Byte',val:ttfb!=null?`${ttfb}ms`:null,target:'< 200ms',cls:ttfb!=null?ttfb<200?'ok':ttfb<600?'warn':'error':'neutral'},
      {label:'FCP (est.)',desc:'First Contentful Paint',val:dcl!=null?`~${dcl}ms`:null,target:'< 1800ms',cls:dcl!=null?dcl<1800?'ok':dcl<3000?'warn':'error':'neutral'},
      {label:'DOM Ready',desc:'DOM Content Loaded',val:dcl!=null?`${dcl}ms`:null,target:'< 1500ms',cls:dcl!=null?dcl<1500?'ok':dcl<3000?'warn':'error':'neutral'},
    ];
    items.forEach(item=>{
      const card=el('div',`ps-cwv-card ${item.cls}`);
      card.innerHTML=`<div class="ps-cwv-label">${item.label}</div><div class="ps-cwv-val">${item.val||'—'}</div><div class="ps-cwv-target">Target: ${item.target}</div><div class="ps-cwv-desc">${item.desc}</div>`;
      cwv.appendChild(card);
    });
  }

  // Resources
  const res=$('psResources');
  if(res){
    res.innerHTML='';
    const items=[
      {icon:'📄',label:'HTML Scripts',val:d.scriptCount,note:d.scriptCount>20?'⚠ Too many':'✓ OK'},
      {icon:'🎨',label:'Stylesheets',val:d.styleCount,note:d.styleCount>5?'⚠ Consider reducing':'✓ OK'},
      {icon:'🖼',label:'Total Images',val:d.images.length,note:''},
      {icon:'⚡',label:'Lazy Loaded',val:d.imagesLazy,note:d.imagesLazy===0&&d.images.length>3?'⚠ Add lazy loading':'✓ Using lazy load'},
      {icon:'✅',label:'Images w/ Alt',val:d.imagesWithAlt,note:d.imagesMissing>0?`⚠ ${d.imagesMissing} missing alt`:'✓ All good'},
    ];
    items.forEach(item=>{
      const row=el('div','ps-res-row');
      row.innerHTML=`<span class="ps-res-icon">${item.icon}</span><span class="ps-res-label">${item.label}</span><span class="ps-res-val">${item.val!=null?item.val:'—'}</span><span class="ps-res-note">${item.note}</span>`;
      res.appendChild(row);
    });
  }

  // CTA links
  const host=d.host||'';
  const psi=$('psiLink'); if(psi)psi.href=`https://pagespeed.web.dev/report?url=${encodeURIComponent('https://'+host)}`;
  const gtm=$('gtmetrixLinkPS'); if(gtm)gtm.href=`https://gtmetrix.com/?url=${encodeURIComponent('https://'+host)}`;
}

/* ─── RENDER: Internal Linking ─── */
let _ilData=null;
function renderInternalLinks(d){
  _ilData=d;
  const links=d.internalLinks||[];

  // Stats
  const sr=$('ilStatsRow');
  if(sr){
    sr.innerHTML='';
    const noAnchor=links.filter(l=>!l.text||l.text.trim().length<2).length;
    const nofollow=links.filter(l=>l.nofollow).length;
    // Count pages linked to
    const pageCounts={};
    links.forEach(l=>{const path=l.href.replace(/^https?:\/\/[^/]+/,'').split('?')[0];pageCounts[path]=(pageCounts[path]||0)+1;});
    const uniquePages=Object.keys(pageCounts).length;
    const stats=[
      {num:links.length,lbl:'Total Internal',cls:''},
      {num:uniquePages,lbl:'Unique Pages',cls:''},
      {num:noAnchor,lbl:'No Anchor',cls:noAnchor>0?'warn':''},
      {num:nofollow,lbl:'Nofollow',cls:''},
    ];
    stats.forEach(s=>{const t=el('div',`il-stat-tile ${s.cls}`);t.innerHTML=`<div class="il-stat-num">${s.num}</div><div class="il-stat-lbl">${s.lbl}</div>`;sr.appendChild(t);});
  }

  // Insights
  const ins=$('ilInsights');
  if(ins){
    ins.innerHTML='';
    const noAnchorLinks=links.filter(l=>!l.text||l.text.trim().length<2);
    if(noAnchorLinks.length>0){const a=el('div','il-insight warn');a.innerHTML=`⚠️ <strong>${noAnchorLinks.length}</strong> internal links have no anchor text — add descriptive anchors for better SEO.`;ins.appendChild(a);}
    const nofollowLinks=links.filter(l=>l.nofollow);
    if(nofollowLinks.length>0){const a=el('div','il-insight info');a.innerHTML=`ℹ️ <strong>${nofollowLinks.length}</strong> internal nofollow links found — these block PageRank flow.`;ins.appendChild(a);}
    if(links.length<5){const a=el('div','il-insight warn');a.innerHTML=`⚠️ Only <strong>${links.length}</strong> internal links — add more to improve crawlability and PageRank distribution.`;ins.appendChild(a);}
    else{const a=el('div','il-insight ok');a.innerHTML=`✅ <strong>${links.length}</strong> internal links detected across this page.`;ins.appendChild(a);}
  }

  renderILList('all',d);

  document.querySelectorAll('.il-filter-btn').forEach(btn=>{
    btn.addEventListener('click',function(){
      document.querySelectorAll('.il-filter-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      renderILList(btn.dataset.ilf,_ilData);
    });
  });
}

function renderILList(filter,d){
  const list=$('ilList'); if(!list)return;
  list.innerHTML='';
  let links=d.internalLinks||[];
  if(filter==='noanchor')links=links.filter(l=>!l.text||l.text.trim().length<2);
  else if(filter==='nofollow')links=links.filter(l=>l.nofollow);
  else if(filter==='top'){
    const pageCounts={};
    links.forEach(l=>{const p=l.href;pageCounts[p]=(pageCounts[p]||0)+1;});
    const sorted=Object.entries(pageCounts).sort((a,b)=>b[1]-a[1]).slice(0,30);
    sorted.forEach(([href,count])=>{
      const row=el('div','il-row');
      let path=''; try{path=new URL(href).pathname;}catch(e){path=href;}
      row.innerHTML=`<div class="il-url-wrap"><div class="il-path">${esc(path)}</div><div class="il-full">${esc(href)}</div></div><span class="il-count-badge">${count} link${count!==1?'s':''}</span>`;
      list.appendChild(row);
    });
    return;
  }
  if(!links.length){list.innerHTML='<div class="il-empty">No links in this category</div>';return;}
  links.slice(0,60).forEach(link=>{
    const row=el('div','il-row');
    let path=''; try{path=new URL(link.href).pathname;}catch(e){path=link.href;}
    const badges=[];
    if(link.nofollow)badges.push('<span class="li-badge nf">nofollow</span>');
    if(link.newTab)badges.push('<span class="li-badge nb">new tab</span>');
    if(!link.text||link.text.trim().length<2)badges.push('<span class="li-badge" style="background:#fef3c7;color:#92400e">no anchor</span>');
    row.innerHTML=`<div class="il-url-wrap"><div class="il-anchor">${esc(link.text||'(no anchor text)')}</div><div class="il-path">${esc(path)}</div></div><div class="li-badges">${badges.join('')}</div>`;
    list.appendChild(row);
  });
}

/* ─── RENDER: SERP ─── */
function renderSERP(d){
  const u=d.url||'',host=d.host||'',path=u.replace(/^https?:\/\/[^/]+/,'')||'/';
  $('serpUrl').textContent=`${host}${path}`;
  $('serpTitle').textContent=d.titleTag||'(No title tag)';
  $('serpDesc').textContent=d.description||'(No meta description)';
  if(d.titleTag&&d.titleTag.length>60)$('serpTitle').classList.add('too-long');
  $('serpMUrl').textContent=host;
  $('serpMTitle').textContent=d.titleTag||'(No title tag)';
  $('serpMDesc').textContent=d.description||'(No description)';
  const cc=$('charCounters'); cc.innerHTML='';
  function charCounter(name,current,ideal_min,ideal_max){
    const pct=clamp(current/ideal_max*100,0,100);
    const cls=current>ideal_max?'error':current<ideal_min?'warn':'ok';
    const colors={ok:'#2B5BCD',warn:'#FEB622',error:'#ef4444'};
    const row=el('div','cc-row');
    row.innerHTML=`<div class="cc-head"><span class="cc-name">${esc(name)}</span><span class="cc-nums ${cls}">${current} / ${ideal_max} chars</span></div><div class="cc-bar"><div class="cc-fill" style="width:${pct}%;background:${colors[cls]}"></div></div><div class="cc-ideal">Ideal: ${ideal_min}–${ideal_max} chars ${current>ideal_max?'⚠ Too long':current<ideal_min?'⚠ Too short':'✓ Good'}</div>`;
    cc.appendChild(row);
  }
  charCounter('Title Tag',d.titleTag.length,30,60);
  charCounter('Meta Description',d.description.length,70,160);
  if(d.openGraph['og:title'])charCounter('OG Title',d.openGraph['og:title'].length,30,90);
  if(d.openGraph['og:description'])charCounter('OG Description',d.openGraph['og:description'].length,50,200);
}

/* ─── RENDER: Meta ─── */
function renderMeta(d){
  function makeGroup(cid,title,rows,badgeStatus){
    const c=$(cid); c.innerHTML='';
    const g=el('div','meta-group');
    const head=el('div','mg-title');
    head.innerHTML=`${esc(title)} <span class="mg-badge ${badgeStatus}">${badgeStatus==='ok'?'Good':badgeStatus==='warn'?'Partial':'Missing'}</span>`;
    g.appendChild(head);
    rows.forEach(([key,val])=>{
      const row=el('div','meta-row');
      const hasVal=val!==null&&val!==undefined&&val!=='';
      row.innerHTML=`<span class="mr-key">${esc(key)}</span><span class="mr-val ${hasVal?'':'missing'}">${hasVal?esc(String(val).length>120?String(val).substring(0,120)+'…':String(val)):'(not set)'}</span><span class="mr-status">${hasVal?'✅':'❌'}</span>`;
      g.appendChild(row);
    });
    c.appendChild(g);
  }
  const basicRows=[['title',d.titleTag],['description',d.description],['keywords',d.keywords],['robots',d.robots],['viewport',d.viewport],['canonical',d.canonical],['author',d.author],['lang (html)',d.lang],['charset',d.charset],['favicon',d.favicon]];
  makeGroup('mgBasic','Basic Meta Tags',basicRows,basicRows.filter(r=>r[1]).length>=6?'ok':basicRows.filter(r=>r[1]).length>=3?'warn':'error');
  const ogRows=[['og:title',d.openGraph['og:title']],['og:description',d.openGraph['og:description']],['og:image',d.openGraph['og:image']],['og:url',d.openGraph['og:url']],['og:type',d.openGraph['og:type']],['og:site_name',d.openGraph['og:site_name']]];
  makeGroup('mgOG','Open Graph',ogRows,ogRows.filter(r=>r[1]).length>=4?'ok':ogRows.filter(r=>r[1]).length>=2?'warn':'error');
  const twRows=[['twitter:card',d.twitter['twitter:card']],['twitter:title',d.twitter['twitter:title']],['twitter:description',d.twitter['twitter:description']],['twitter:image',d.twitter['twitter:image']],['twitter:site',d.twitter['twitter:site']]];
  makeGroup('mgTwitter','Twitter / X Card',twRows,twRows.filter(r=>r[1]).length>=3?'ok':twRows.filter(r=>r[1]).length>=1?'warn':'error');
  const otherRows=Object.entries(d.metas).filter(([k])=>!k.startsWith('og:')&&!k.startsWith('twitter:')&&!['description','keywords','robots','viewport','author'].includes(k)).slice(0,15);
  if(otherRows.length>0)makeGroup('mgOther','Other Meta Tags',otherRows,'ok');
}

/* ─── RENDER: Headings ─── */
function renderHeadings(d){
  const stats=$('hStats'); stats.innerHTML='';
  const counts={1:0,2:0,3:0,4:0,5:0,6:0};
  d.headings.forEach(h=>counts[h.level]++);
  [1,2,3,4,5,6].forEach(n=>{
    if(n>3&&counts[n]===0)return;
    const pill=el('div',`hs-pill ${n===1&&counts[1]===0?'error':n===1&&counts[1]>1?'warn':''}`);
    pill.innerHTML=`<span class="hp-tag">H${n}</span><span class="hp-num">${counts[n]}</span>`;
    stats.appendChild(pill);
  });
  const alerts=$('hAlerts'); alerts.innerHTML='';
  if(counts[1]===0){const a=el('div','h-alert error');a.innerHTML='❌ No H1 heading found — every page should have exactly one H1';alerts.appendChild(a);}
  else if(counts[1]>1){const a=el('div','h-alert warn');a.innerHTML=`⚠️ ${counts[1]} H1 tags found — use only one H1 per page`;alerts.appendChild(a);}
  if(counts[2]===0&&d.headings.length>0){const a=el('div','h-alert warn');a.innerHTML='⚠️ No H2 headings — consider adding subheadings';alerts.appendChild(a);}
  const outline=$('hOutline'); outline.innerHTML='';
  if(d.headings.length===0){outline.innerHTML='<div style="text-align:center;padding:20px;color:#94a3b8;font-size:0.75rem">No headings found</div>';return;}
  d.headings.forEach(h=>{const node=el('div','h-node');node.dataset.lvl=h.level;node.innerHTML=`<span class="hn-tag">H${h.level}</span><span class="hn-txt">${esc(h.text)}</span>`;outline.appendChild(node);});
}

/* ─── RENDER: Links ─── */
let linksData=[];
function renderLinks(d){
  linksData=d;
  const stats=$('linksStats'); stats.innerHTML='';
  [{num:d.links.length,lbl:'Total'},{num:d.internalLinks.length,lbl:'Internal'},{num:d.externalLinks.length,lbl:'External'},{num:d.nofollowLinks.length,lbl:'Nofollow'}].forEach((s,i)=>{
    const t=el('div',`ls-tile${i===0?' highlight':''}`);
    t.innerHTML=`<div class="lt-num">${s.num}</div><div class="lt-lbl">${s.lbl}</div>`;
    stats.appendChild(t);
  });
  renderLinksList('internal',d);
  document.querySelectorAll('.lt-btn').forEach(btn=>{btn.addEventListener('click',()=>{document.querySelectorAll('.lt-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');renderLinksList(btn.dataset.lt,linksData);});});
}
function renderLinksList(type,d){
  const body=$('linksBody'); body.innerHTML='';
  const list=type==='internal'?d.internalLinks:type==='external'?d.externalLinks:d.nofollowLinks;
  if(!list||list.length===0){body.innerHTML=`<div style="text-align:center;padding:20px;color:#94a3b8;font-size:0.75rem">No ${type} links found</div>`;return;}
  list.slice(0,50).forEach(link=>{
    const item=el('div','link-item');
    const badges=[];
    if(link.nofollow)badges.push('<span class="li-badge nf">nofollow</span>');
    if(link.sponsored)badges.push('<span class="li-badge sp">sponsored</span>');
    if(!link.nofollow)badges.push('<span class="li-badge df">dofollow</span>');
    if(link.newTab)badges.push('<span class="li-badge nb">new tab</span>');
    item.innerHTML=`<div class="li-anchor"><div class="li-text">${esc(link.text||link.href)}</div><div class="li-href">${esc(link.href)}</div></div><div class="li-badges">${badges.join('')}</div>`;
    body.appendChild(item);
  });
}

/* ─── RENDER: Images ─── */
let imagesData=[];
function renderImages(d){
  imagesData=d;
  const stats=$('imgStats'); stats.innerHTML='';
  [{num:d.images.length,lbl:'Total'},{num:d.imagesWithAlt,lbl:'Has Alt'},{num:d.imagesMissing,lbl:'No Alt'},{num:d.imagesLazy,lbl:'Lazy'}].forEach((s,i)=>{
    const t=el('div',`ls-tile${i===0?' highlight':''}`);
    t.innerHTML=`<div class="lt-num">${s.num}</div><div class="lt-lbl">${s.lbl}</div>`;
    stats.appendChild(t);
  });
  renderImagesList('all',d);
  document.querySelectorAll('.if-btn').forEach(btn=>{btn.addEventListener('click',()=>{document.querySelectorAll('.if-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');renderImagesList(btn.dataset.if,imagesData);});});
}
function renderImagesList(filter,d){
  const list=$('imgList'); list.innerHTML='';
  let imgs=d.images||[];
  if(filter==='missing')imgs=imgs.filter(i=>!i.hasAlt||i.altEmpty);
  if(filter==='lazy')imgs=imgs.filter(i=>i.loading==='lazy');
  if(!imgs.length){list.innerHTML=`<div style="text-align:center;padding:20px;color:#94a3b8;font-size:0.75rem">No images in this category</div>`;return;}
  imgs.slice(0,25).forEach(img=>{
    const hasAlt=img.hasAlt&&!img.altEmpty;
    const item=el('div',`img-item ${hasAlt?'has-alt':'missing-alt'}`);
    const badges=[];
    if(hasAlt)badges.push('<span class="ii-badge ok">✓ Alt</span>');
    else badges.push('<span class="ii-badge error">No Alt</span>');
    if(img.loading==='lazy')badges.push('<span class="ii-badge info">Lazy</span>');
    if(img.srcset)badges.push('<span class="ii-badge info">srcset</span>');
    item.innerHTML=`<img class="ii-thumb" src="${esc(img.src)}" alt="" loading="lazy" onerror="this.style.background='#f1f5f9'"/><div class="ii-info"><div class="ii-alt">${hasAlt?esc(img.alt):'(no alt text)'}</div><div class="ii-src">${esc(img.src.split('/').pop().slice(0,40))}</div></div><div class="ii-badges">${badges.join('')}</div>`;
    list.appendChild(item);
  });
}

/* ─── RENDER: Technical ─── */
function renderTechnical(d){
  const sections=$('techSections'); sections.innerHTML='';
  const groups=[
    {icon:'🔒',title:'Security & Indexability',rows:[
      {icon:'🔒',label:'HTTPS',val:d.isHttps?'Secure':'Not Secure',cls:d.isHttps?'ok':'error'},
      {icon:'🤖',label:'Robots',val:d.robots||'index, follow (default)',cls:d.isNoindex?'error':'ok'},
      {icon:'🚫',label:'Noindex',val:d.isNoindex?'YES — Not indexable':'No — Indexable',cls:d.isNoindex?'error':'ok'},
      {icon:'🔗',label:'Canonical URL',val:d.canonical||'Not set',cls:d.canonical?'ok':'warn'},
    ]},
    {icon:'📱',title:'Page Basics',rows:[
      {icon:'📄',label:'Doctype',val:d.doctype||'Missing',cls:d.doctype==='HTML'?'ok':'warn'},
      {icon:'🌍',label:'Language',val:d.lang||'Not set',cls:d.lang?'ok':'warn'},
      {icon:'📱',label:'Viewport',val:d.viewport||'Missing',cls:d.viewport?'ok':'error'},
      {icon:'🔤',label:'Charset',val:d.charset||'Not declared',cls:'neutral'},
      {icon:'⭐',label:'Favicon',val:d.favicon?'Present':'Missing',cls:d.favicon?'ok':'warn'},
    ]},
    {icon:'📊',title:'Content Signals',rows:[
      {icon:'📖',label:'Word Count',val:`${d.wordCount.toLocaleString()} words`,cls:d.wordCount>=300?'ok':'warn'},
      {icon:'📊',label:'Schema Markup',val:d.structuredData.length>0?`${d.structuredData.length} schema(s)`:'None',cls:d.structuredData.length>0?'ok':'warn'},
      {icon:'🖼',label:'Images (total)',val:d.images.length,cls:'neutral'},
      {icon:'✅',label:'Images with Alt',val:`${d.imagesWithAlt} / ${d.images.length}`,cls:d.imagesMissing===0?'ok':'warn'},
      {icon:'⚡',label:'Lazy Images',val:d.imagesLazy>0?`${d.imagesLazy} lazy`:'None',cls:d.imagesLazy>0?'ok':'warn'},
    ]},
    {icon:'⚡',title:'Performance Hints',rows:[
      {icon:'🕐',label:'TTFB',val:d.ttfb!=null?`${d.ttfb}ms`:'N/A',cls:d.ttfb!=null?d.ttfb<200?'ok':d.ttfb<600?'warn':'error':'neutral'},
      {icon:'⏱',label:'DOM Ready',val:d.domContentLoaded!=null?`${d.domContentLoaded}ms`:'N/A',cls:d.domContentLoaded!=null?d.domContentLoaded<1500?'ok':d.domContentLoaded<3000?'warn':'error':'neutral'},
      {icon:'🚀',label:'Load Time',val:d.loadTime!=null?`${d.loadTime}ms`:'N/A',cls:d.loadTime!=null?d.loadTime<3000?'ok':d.loadTime<6000?'warn':'error':'neutral'},
      {icon:'📝',label:'Scripts',val:d.scriptCount,cls:d.scriptCount<20?'ok':'warn'},
      {icon:'🎨',label:'Stylesheets',val:d.styleCount,cls:d.styleCount<10?'ok':'warn'},
    ]},
    {icon:'🔵',title:'Social Media',rows:[
      {icon:'📘',label:'OG Tags',val:Object.keys(d.openGraph).length>0?`${Object.keys(d.openGraph).length} present`:'Missing',cls:Object.keys(d.openGraph).length>0?'ok':'warn'},
      {icon:'🖼',label:'OG Image',val:d.openGraph['og:image']?'Set':'Missing',cls:d.openGraph['og:image']?'ok':'warn'},
      {icon:'🐦',label:'Twitter Card',val:d.twitter['twitter:card']||'Missing',cls:d.twitter['twitter:card']?'ok':'warn'},
    ]},
  ];
  groups.forEach(group=>{
    const g=el('div','tech-group');
    const head=el('div','tg-head');
    head.innerHTML=`<span class="tg-icon">${group.icon}</span>${esc(group.title)}`;
    g.appendChild(head);
    const rows=el('div','tg-rows');
    group.rows.forEach(row=>{
      const r=el('div','tech-row');
      r.innerHTML=`<span class="tr-label"><span class="tr-icon">${row.icon}</span>${esc(row.label)}</span><span class="tr-val ${row.cls}">${esc(String(row.val))}</span>`;
      rows.appendChild(r);
    });
    g.appendChild(rows); sections.appendChild(g);
  });
}

/* ─── RENDER: Site Audit ─── */
function renderSiteAudit(d){
  if($('saTotalPages'))$('saTotalPages').textContent=d.estimatedPages||0;
  if($('saBlogPosts'))$('saBlogPosts').textContent=d.estimatedBlogPosts||0;
  if($('saExtLinks'))$('saExtLinks').textContent=d.externalLinks?d.externalLinks.length:0;
  if($('saTechScore'))$('saTechScore').textContent=calcTechHealth(d);
}

/* ─── RENDER: Indexed Pages ─── */
let _indexedData={all:[],blog:[],other:[]};
function renderIndexedPages(d){
  const blogUrls=d.blogPostUrls||[],otherUrls=d.pageUrls||[];
  const allUrls=[...new Set([...blogUrls,...otherUrls])];
  _indexedData={all:allUrls,blog:blogUrls,other:otherUrls};
  if($('idxTotalCount'))$('idxTotalCount').textContent=allUrls.length;
  if($('idxBlogCount'))$('idxBlogCount').textContent=blogUrls.length;
  if($('idxOtherCount'))$('idxOtherCount').textContent=otherUrls.length;
  renderIndexedList('all');
  document.querySelectorAll('.idx-filter-btn').forEach(btn=>{btn.addEventListener('click',function(){document.querySelectorAll('.idx-filter-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active');renderIndexedList(btn.dataset.ifilter);});});
  const dlp=$('btnDownloadPages'); if(dlp)dlp.addEventListener('click',downloadPages);
}
function renderIndexedList(filter){
  const list=$('idxList'); if(!list)return;
  list.innerHTML='';
  const urls=_indexedData[filter]||_indexedData.all;
  if(!urls.length){list.innerHTML='<div class="idx-empty">No pages detected in this category</div>';return;}
  urls.forEach(function(url,i){
    const isBlog=_indexedData.blog.includes(url);
    const row=el('div','idx-row');
    let path=''; try{path=new URL(url).pathname;}catch(e){path=url;}
    row.innerHTML=`<span class="idx-num">${i+1}</span><div class="idx-url-wrap"><div class="idx-path">${esc(path)}</div><div class="idx-full">${esc(url)}</div></div><span class="idx-type-badge ${isBlog?'blog':'page'}">${isBlog?'Blog':'Page'}</span>`;
    list.appendChild(row);
  });
}

/* ─── DOWNLOAD CSV ─── */
function downloadReport(){
  if(!_seoData)return;
  const d=_seoData,now=new Date().toISOString().slice(0,19).replace('T',' ');
  const rows=[['7th Club SEO Report'],['Generated',now],['URL',d.url],[],
    ['SEO Score',calcScore(d).score+'/100'],['Tech Health',calcTechHealth(d)],[],
    ['Title Tag',d.titleTag],['Title Length',d.titleTag.length+' chars'],
    ['Meta Description',d.description],['Description Length',d.description.length+' chars'],
    ['H1 Count',d.h1Count],['HTTPS',d.isHttps?'Yes':'No'],['Canonical',d.canonical||'Not set'],
    ['Language',d.lang||'Not set'],['Viewport',d.viewport||'Missing'],
    ['Noindex',d.isNoindex?'YES':'No'],['Word Count',d.wordCount],
    ['Schema Markup',d.structuredData.length+' schema(s)'],
    [],['SITE CONTENT'],['Est. Pages',d.estimatedPages],['Est. Blog Posts',d.estimatedBlogPosts],
    ['Total Links',d.links.length],['Internal Links',d.internalLinks.length],
    ['External Links',d.externalLinks.length],['Total Images',d.images.length],
    ['Images With Alt',d.imagesWithAlt],['Images Missing Alt',d.imagesMissing],
    [],['PERFORMANCE'],
    ['TTFB',d.ttfb!=null?d.ttfb+'ms':'N/A'],
    ['DOM Ready',d.domContentLoaded!=null?d.domContentLoaded+'ms':'N/A'],
    ['Load Time',d.loadTime!=null?d.loadTime+'ms':'N/A'],
    ['Scripts',d.scriptCount],['Stylesheets',d.styleCount],
  ];
  if(d.blogPostUrls&&d.blogPostUrls.length>0){rows.push([],['BLOG POST URLs']);d.blogPostUrls.forEach(u=>rows.push([u]));}
  if(d.pageUrls&&d.pageUrls.length>0){rows.push([],['PAGE URLs']);d.pageUrls.slice(0,100).forEach(u=>rows.push([u]));}
  const csv=rows.map(r=>r.map(v=>'"'+String(v||'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob); a.download='7thclub-seo-'+((d.host||'site'))+'.csv'; a.click();
}
function downloadPages(){
  const rows=[['#','Type','Path','Full URL']];
  _indexedData.all.forEach((url,i)=>{const isBlog=_indexedData.blog.includes(url);let path='';try{path=new URL(url).pathname;}catch(e){path=url;}rows.push([i+1,isBlog?'Blog Post':'Page',path,url]);});
  const csv=rows.map(r=>r.map(v=>'"'+String(v||'').replace(/"/g,'""')+'"').join(',')).join('\r\n');
  const blob=new Blob([csv],{type:'text/csv;charset=utf-8;'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob); a.download='7thclub-indexed-pages.csv'; a.click();
}


/* ─── AUDIT REPORT — Full Detailed Professional Report ─── */
function getFixTip(text){
  const tips={
    'Title tag is missing':'Add a unique descriptive <title> tag (30–60 chars) containing your primary keyword',
    'Title too short':'Expand title to include primary keyword + brand name, aim for 50–60 characters',
    'Title too long':'Trim to under 60 characters — Google truncates longer titles in search results',
    'Meta description missing':'Write a compelling 120–155 char description with target keywords and a call-to-action',
    'Description too short':'Expand to at least 70 characters — include keywords and an action phrase',
    'Description too long':'Cut to under 160 characters to prevent truncation in SERPs',
    'No H1 heading found':'Add exactly one H1 tag that clearly states the page topic and primary keyword',
    'Multiple H1 tags':'Remove extra H1s — demote them to H2 or H3 headings instead',
    'Page not served over HTTPS':'Install an SSL certificate and force HTTPS redirects — it is a confirmed ranking factor',
    'No canonical URL defined':'Add <link rel="canonical" href="full-url"/> in your <head> section',
    'Missing lang attribute':'Add lang="en" (or correct language code) to the opening <html> tag',
    'Missing viewport meta tag':'Add <meta name="viewport" content="width=device-width, initial-scale=1">',
    'Page is set to noindex':'Remove the noindex directive unless deliberately hiding this page from search engines',
    'missing alt text':'Add descriptive alt attributes to every image — include keywords where natural',
    'No Open Graph tags found':'Add og:title, og:description, og:image and og:url tags for better social sharing',
    'Missing og:image tag':'Add a 1200×630px og:image — required for rich social previews on Facebook & LinkedIn',
    'Missing Twitter Card tags':'Add twitter:card, twitter:title, twitter:description and twitter:image meta tags',
    'No structured data':'Add JSON-LD schema — start with Organization + WebPage for instant SEO benefit',
    'Low word count':'Write at least 300 words; aim for 1 000+ on competitive topics for better rankings',
  };
  for(const[k,v]of Object.entries(tips)){if(text.toLowerCase().includes(k.toLowerCase()))return v;}
  return 'Review this element and improve it following SEO best practices';
}

function generateAuditReport(){
  if(!_seoData)return;
  const d=_seoData;
  const {score,issues}=calcScore(d);
  const errors=issues.filter(i=>i.sev==='error');
  const warns=issues.filter(i=>i.sev==='warn');
  const passedCount=Math.max(0,12-errors.length-warns.length);
  const kd=calcKeywordDensity(d.bodyText||'',Math.max(d.wordCount,1));
  const techH=calcTechHealth(d);
  const techNum=parseInt(techH)||0;
  const now=new Date().toLocaleDateString('en-GB',{year:'numeric',month:'long',day:'numeric'});
  const nowTime=new Date().toLocaleTimeString('en-GB',{hour:'2-digit',minute:'2-digit'});
  const tl=d.titleTag.length,dl=d.description.length;
  /* Brand colors matching 7thclub.com */
  const B='#3B5DD4',BDK='#1e3a8a',ORANGE='#F97316',GOLD='#FEB622';
  const scoreCol=score>=80?B:score>=60?GOLD:'#ef4444';
  const scoreLbl=score>=90?'Excellent':score>=80?'Good':score>=60?'Needs Work':score>=40?'Poor':'Critical';
  const hdCounts={1:0,2:0,3:0,4:0,5:0,6:0};
  d.headings.forEach(h=>{if(hdCounts[h.level]!==undefined)hdCounts[h.level]++;});
  let speedScore=100;
  if(d.ttfb!=null){if(d.ttfb>600)speedScore-=30;else if(d.ttfb>200)speedScore-=15;}
  if(d.domContentLoaded!=null){if(d.domContentLoaded>3000)speedScore-=25;else if(d.domContentLoaded>1500)speedScore-=12;}
  if(d.loadTime!=null){if(d.loadTime>6000)speedScore-=25;else if(d.loadTime>3000)speedScore-=12;}
  speedScore=Math.max(0,Math.min(100,speedScore));
  const speedCol=speedScore>=80?B:speedScore>=50?GOLD:'#ef4444';
  const speedLbl=speedScore>=80?'Fast':speedScore>=50?'Needs Improvement':'Slow';

  /* ── helpers ── */
  const ring=(val,max,col,size=90)=>{
    const r=size*0.4,circ=2*Math.PI*r,offset=circ-(val/max)*circ;
    const cx=size/2,cy=size/2;
    return `<svg width="${size}" height="${size}" style="transform:rotate(-90deg)">
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#e8eaf6" stroke-width="${size*0.09}"/>
      <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${col}" stroke-width="${size*0.09}"
        stroke-linecap="round" stroke-dasharray="${circ.toFixed(1)}" stroke-dashoffset="${offset.toFixed(1)}"
        style="filter:drop-shadow(0 0 6px ${col}88)"/>
    </svg>`;
  };
  const bar=(pct,col=B,h=10)=>`<div style="background:#e8eaf6;border-radius:${h}px;height:${h}px;overflow:hidden"><div style="height:100%;width:${Math.min(100,pct).toFixed(1)}%;background:${col};border-radius:${h}px;transition:width 0.8s ease"></div></div>`;
  const chip=(txt,bg,col,brd)=>`<span style="display:inline-flex;align-items:center;padding:4px 12px;border-radius:20px;font-size:0.72rem;font-weight:700;background:${bg};color:${col};border:1.5px solid ${brd}">${txt}</span>`;
  const statusChip=(cls,txt)=>{
    const map={ok:['#dcfce7','#14532d','#86efac'],warn:['#ffedd5','#7c2d12','#fb923c'],error:['#fee2e2','#7f1d1d','#f87171'],neutral:['#f1f5f9','#475569','#cbd5e1']};
    const [bg,col,brd]=map[cls]||map.neutral;
    return chip(txt,bg,col,brd);
  };
  /* Section header with orange accent bar */
  const secHead=(emoji,title,sub='')=>`
    <div style="display:flex;align-items:center;gap:14px;margin-bottom:24px;padding-bottom:14px;border-bottom:3px solid #3B5DD4">
      <div style="width:46px;height:46px;background:linear-gradient(135deg,#3B5DD4,#1e3a8a);
        border-radius:12px;display:flex;align-items:center;justify-content:center;
        font-size:1.4rem;flex-shrink:0;box-shadow:0 4px 14px rgba(59,93,212,0.35)">${emoji}</div>
      <div style="flex:1">
        <div style="font-size:1.15rem;font-weight:900;color:#1e3a8a;letter-spacing:-0.3px">${title}</div>
        ${sub?`<div style="font-size:0.8rem;color:#6b7280;margin-top:2px">${sub}</div>`:''}
      </div>
      <div style="width:8px;height:8px;background:#F97316;border-radius:50%"></div>
    </div>`;
  const box=(content,brdCol='#e8eaf6',bgCol='#fff')=>
    `<div style="background:${bgCol};border:2px solid ${brdCol};border-radius:14px;overflow:hidden;margin-bottom:16px">${content}</div>`;
  const infoRow=(icon,label,val,cls='neutral',tip='')=>`
    <div style="display:flex;align-items:center;gap:12px;padding:12px 16px;border-bottom:1px solid #eef0f8;
      ${cls==='error'?'background:#fff1f2;border-left:5px solid #ef4444;':
        cls==='warn'?'background:#fff7ed;border-left:5px solid #F97316;':
        cls==='ok'?'background:#f0fdf4;border-left:5px solid #16a34a;':
        'background:#fff;border-left:5px solid #e8eaf6;'}">
      <span style="font-size:1rem;width:24px;text-align:center;flex-shrink:0">${icon}</span>
      <span style="flex:1;font-size:0.85rem;font-weight:600;color:${cls==='error'?'#7f1d1d':cls==='warn'?'#7c2d12':'#374151'}">${label}</span>
      <span style="font-family:monospace;font-size:0.82rem;font-weight:700;color:#111827;max-width:260px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right">${esc(String(val).slice(0,80))}</span>
      ${statusChip(cls,cls==='ok'?'✓ Good':cls==='warn'?'⚠ Fix':cls==='error'?'✗ Error':'—')}
    </div>`;

  const html=`<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title>SEO Audit — ${esc(d.host||'Site')} · 7th Club</title>
<style>
  *{box-sizing:border-box;margin:0;padding:0}
  body{font-family:'Segoe UI',Arial,sans-serif;background:#ffffff;color:#111827;line-height:1.6;-webkit-print-color-adjust:exact;print-color-adjust:exact;font-size:15px}
  .page{max-width:1000px;margin:0 auto;background:#fff;border:1px solid #3B5DD4}
  a{color:#3B5DD4;text-decoration:none}
  a:hover{color:#1e3a8a;text-decoration:underline}

  /* ── TABLES ── */
  table{width:100%;border-collapse:collapse;border-radius:12px;overflow:hidden;border:2px solid #3B5DD4;box-shadow:0 2px 12px rgba(59,93,212,0.10)}
  th{background:linear-gradient(90deg,#1e3a8a,#3B5DD4);color:#fff;padding:12px 16px;text-align:left;font-size:0.8rem;font-weight:700;text-transform:uppercase;letter-spacing:.6px}
  td{padding:11px 16px;border-bottom:1px solid #dbeafe;font-size:0.88rem;vertical-align:middle;background:#fff}
  tr:last-child td{border-bottom:none}
  tr:nth-child(even) td{background:#f7f9ff}
  tr:hover td{background:#eef2ff!important}
  .ok    {color:#15803d;font-weight:800}
  .warn  {color:#c2580a;font-weight:800}
  .error {color:#b91c1c;font-weight:800}
  .mono  {font-family:'Courier New',monospace;font-size:0.82rem}

  /* ── COLORED TABLE ROWS — red/orange/green fills ── */
  tr.row-error td{background:#ef4444!important;color:#fff!important;font-weight:700;border-bottom:2px solid #dc2626!important}
  tr.row-error td *{color:#fff!important}
  tr.row-error:hover td{background:#dc2626!important}
  tr.row-warn  td{background:#fff3e6!important;border-left:4px solid #F97316;border-bottom:1px solid #fed7aa}
  tr.row-warn:hover td{background:#ffe8cc!important}
  tr.row-ok    td{background:#f0fdf4!important;border-left:4px solid #16a34a;border-bottom:1px solid #bbf7d0}
  tr.row-ok:hover td{background:#dcfce7!important}

  /* ── SECTIONS — white with strong blue bottom rule ── */
  .section{padding:32px 44px;border-bottom:3px solid #dbeafe;background:#fff}
  .section:last-child{border-bottom:none}

  /* ── BLUE CARD BOX — white bg, blue border ── */
  .blue-box{background:#fff;border:2px solid #3B5DD4;border-radius:14px;overflow:hidden;margin-bottom:16px;box-shadow:0 2px 12px rgba(59,93,212,0.08)}
  .blue-box-header{background:linear-gradient(90deg,#1e3a8a,#3B5DD4);padding:12px 18px;color:#fff;font-size:0.82rem;font-weight:800;display:flex;align-items:center;gap:8px}
  .blue-box-body{padding:16px 18px;background:#fff}

  /* ── ORANGE ACCENT BOX ── */
  .orange-box{background:#fff;border:2px solid #F97316;border-radius:14px;overflow:hidden;margin-bottom:16px}
  .orange-box-header{background:linear-gradient(90deg,#c2580a,#F97316);padding:12px 18px;color:#fff;font-size:0.82rem;font-weight:800;display:flex;align-items:center;gap:8px}
  .orange-box-body{padding:16px 18px}

  /* ── ERROR CARD (solid red) ── */
  .error-card{background:#ef4444;border:2px solid #b91c1c;border-radius:12px;overflow:hidden;margin-bottom:10px}
  .error-card-head{background:#b91c1c;padding:11px 18px;color:#fff;font-weight:800;font-size:0.9rem;display:flex;align-items:center;gap:10px}
  .error-card-body{background:#ef4444;padding:12px 18px;color:#fff;font-size:0.8rem;line-height:1.6}
  .error-card-body strong{color:#fecaca}

  /* ── WARN CARD ── */
  .warn-card{background:#fff7ed;border:2px solid #F97316;border-radius:12px;overflow:hidden;margin-bottom:10px}
  .warn-card-head{background:linear-gradient(90deg,#c2580a,#F97316);padding:10px 18px;color:#fff;font-weight:800;font-size:0.88rem;display:flex;align-items:center;gap:10px}
  .warn-card-body{padding:12px 18px;color:#7c2d12;font-size:0.8rem;line-height:1.6}
  .warn-card-body strong{color:#9a3412}

  /* ── STAT TILES ── */
  .stat-grid{display:grid;gap:10px;margin-bottom:20px}
  .stat-tile{border-radius:12px;padding:14px 16px;text-align:center}
  .stat-tile .st-num{font-size:1.7rem;font-weight:900;line-height:1}
  .stat-tile .st-lbl{font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;margin-top:4px;opacity:.75}
  .stat-tile.blue  {background:#fff;border:2px solid #3B5DD4;color:#1e3a8a}
  .stat-tile.green {background:#f0fdf4;border:2px solid #16a34a;color:#14532d}
  .stat-tile.red   {background:#ef4444;border:2px solid #b91c1c;color:#fff}
  .stat-tile.red .st-lbl{opacity:0.85}
  .stat-tile.orange{background:#fff7ed;border:2px solid #F97316;color:#7c2d12}
  .stat-tile.grey  {background:#fff;border:2px solid #cbd5e1;color:#374151}

  /* ── CHIP / BADGE ── */
  .chip{display:inline-flex;align-items:center;padding:4px 12px;border-radius:20px;font-size:0.72rem;font-weight:700}
  .chip-ok    {background:#dcfce7;color:#14532d;border:1.5px solid #86efac}
  .chip-warn  {background:#ffedd5;color:#7c2d12;border:1.5px solid #fb923c}
  .chip-error {background:#ef4444;color:#fff;border:1.5px solid #b91c1c}
  .chip-grey  {background:#f1f5f9;color:#475569;border:1.5px solid #cbd5e1}

  /* ── PROGRESS BAR ── */
  .prog-track{background:#e8eaf6;border-radius:8px;height:10px;overflow:hidden;margin:6px 0}
  .prog-fill {height:100%;border-radius:8px;transition:width .8s ease}
  .prog-blue  .prog-fill{background:#3B5DD4}
  .prog-green .prog-fill{background:#16a34a}
  .prog-orange.prog-fill, .prog-orange .prog-fill{background:#F97316}
  .prog-red   .prog-fill{background:#ef4444}

  @media print{body{background:#fff}.page{margin:0;box-shadow:none} .no-print{display:none!important} .pb{page-break-before:always}}
</style>
</head>
<body>
<div class="page">

<!-- ═══════════ COVER HEADER — WHITE THEME ═══════════ -->
<div style="background:#fff;border-bottom:4px solid #3B5DD4;position:relative;overflow:hidden">

  <!-- top orange accent stripe -->
  <div style="height:5px;background:linear-gradient(90deg,#3B5DD4,#F97316,#FEB622,#F97316,#3B5DD4)"></div>

  <!-- logo bar -->
  <div style="padding:28px 48px 22px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #dbeafe">
    <div style="display:flex;align-items:center;gap:16px">
      <img src="https://7thclub.com/wp-content/uploads/2025/02/Logo.png"
        style="height:60px;object-fit:contain"
        alt="7th Club"
        onerror="this.outerHTML='<span style=font-size:2rem;font-weight:900;color:#3B5DD4;letter-spacing:1px>7THCLUB</span>'"/>
      <div style="border-left:2px solid #dbeafe;padding-left:16px">
        <div style="font-size:0.65rem;font-weight:800;text-transform:uppercase;letter-spacing:3px;color:#3B5DD4">SEO Analyzer Pro</div>
        <div style="font-size:0.72rem;color:#6b7280;margin-top:2px">by 7thclub.com</div>
      </div>
    </div>
    <div style="text-align:right">
      <div style="font-size:2rem;font-weight:900;color:#1e3a8a;letter-spacing:-0.5px;line-height:1">SEO Audit Report</div>
      <div style="font-size:0.95rem;color:#3B5DD4;font-weight:600;margin-top:5px">${esc(d.host||'Website')}</div>
      <div style="display:inline-flex;align-items:center;gap:8px;background:#F97316;border-radius:8px;padding:6px 16px;margin-top:10px">
        <span style="color:#fff;font-size:0.8rem">📅</span>
        <span style="color:#fff;font-size:0.8rem;font-weight:800">${now} · ${nowTime}</span>
      </div>
    </div>
  </div>

  <!-- URL badge -->
  <div style="margin:16px 48px;background:#f0f4ff;border:2px solid #3B5DD4;border-radius:10px;padding:11px 18px;display:flex;align-items:center;gap:10px">
    <span style="background:${d.isHttps?'#16a34a':'#ef4444'};color:#fff;font-size:0.7rem;font-weight:800;padding:4px 10px;border-radius:6px;flex-shrink:0">${d.isHttps?'🔒 HTTPS':'⚠ HTTP'}</span>
    <a href="${esc(d.url||'#')}" target="_blank" style="color:#1e3a8a;font-family:monospace;font-size:0.85rem;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:600">${esc(d.url||'')}</a>
    <span style="background:${d.isNoindex?'#ef4444':'#16a34a'};color:#fff;font-size:0.68rem;font-weight:800;padding:4px 10px;border-radius:6px;flex-shrink:0">${d.isNoindex?'NOINDEX':'✓ INDEXED'}</span>
  </div>

  <!-- SCORE HERO -->
  <div style="padding:24px 48px 36px;display:flex;gap:36px;align-items:center">

    <!-- score ring -->
    <div style="position:relative;width:150px;height:150px;flex-shrink:0">
      ${ring(score,100,scoreCol,150)}
      <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
        <div style="font-size:2.8rem;font-weight:900;color:${scoreCol};line-height:1">${score}</div>
        <div style="font-size:0.56rem;font-weight:800;color:#6b7280;text-transform:uppercase;letter-spacing:2px;margin-top:3px">SEO SCORE</div>
      </div>
    </div>

    <!-- summary -->
    <div style="flex:1">
      <div style="font-size:1.4rem;font-weight:900;color:#1e3a8a;margin-bottom:4px;line-height:1.3">${esc(d.titleTag||d.host||'Untitled Page')}</div>
      <div style="font-size:0.85rem;color:#374151;margin-bottom:18px">
        Overall Grade: <strong style="color:${scoreCol}">${scoreLbl}</strong>
        &nbsp;·&nbsp; Tech Health: <strong style="color:${techNum>=80?'#16a34a':techNum>=60?'#F97316':'#ef4444'}">${techH}</strong>
        &nbsp;·&nbsp; Words: <strong style="color:#3B5DD4">${d.wordCount.toLocaleString()}</strong>
      </div>
      <!-- stat tiles — solid fills for quick visual scan -->
      <div style="display:flex;gap:8px;flex-wrap:wrap">
        ${[
          {n:errors.length,  lbl:'Critical Errors', bg:errors.length>0?'#ef4444':'#f0fdf4', brd:errors.length>0?'#b91c1c':'#86efac', col:errors.length>0?'#fff':'#16a34a', lblcol:errors.length>0?'rgba(255,255,255,0.85)':'#14532d'},
          {n:warns.length,   lbl:'Warnings',         bg:warns.length>0?'#F97316':'#f0fdf4',  brd:warns.length>0?'#c2580a':'#86efac',  col:warns.length>0?'#fff':'#16a34a',  lblcol:warns.length>0?'rgba(255,255,255,0.85)':'#14532d'},
          {n:passedCount,    lbl:'Checks Passed',    bg:'#f0fdf4',  brd:'#86efac',  col:'#16a34a', lblcol:'#14532d'},
          {n:d.links.length, lbl:'Total Links',      bg:'#eff4ff',  brd:'#3B5DD4',  col:'#1e3a8a', lblcol:'#1e3a8a'},
          {n:d.images.length,lbl:'Images Found',     bg:'#faf5ff',  brd:'#7c3aed',  col:'#5b21b6', lblcol:'#5b21b6'},
          {n:d.structuredData.length,lbl:'Schema',   bg:'#ecfeff',  brd:'#0891b2',  col:'#0e7490', lblcol:'#0e7490'},
        ].map(s=>`
        <div style="background:${s.bg};border:2px solid ${s.brd};border-radius:12px;padding:12px 16px;min-width:80px;text-align:center;flex:1;box-shadow:0 2px 8px rgba(0,0,0,0.06)">
          <div style="font-size:1.7rem;font-weight:900;color:${s.col};line-height:1">${s.n}</div>
          <div style="font-size:0.58rem;font-weight:800;color:${s.lblcol};text-transform:uppercase;letter-spacing:.4px;margin-top:4px;opacity:0.9">${s.lbl}</div>
        </div>`).join('')}
      </div>
    </div>
  </div>
</div>

<!-- ═══════════════════════════
     QUICK-GLANCE STATUS BAR
═══════════════════════════ -->
<div style="background:#fff;border-bottom:4px solid #3B5DD4;padding:18px 40px;display:grid;grid-template-columns:repeat(7,1fr);gap:8px">
  ${[
    {lbl:'Title',val:d.titleTag?`${tl}c`:'Missing',cls:!d.titleTag?'error':tl>=30&&tl<=60?'ok':'warn'},
    {lbl:'Description',val:d.description?`${dl}c`:'Missing',cls:!d.description?'error':dl>=70&&dl<=160?'ok':'warn'},
    {lbl:'H1 Tag',val:`${hdCounts[1]} found`,cls:hdCounts[1]===1?'ok':hdCounts[1]===0?'error':'warn'},
    {lbl:'HTTPS',val:d.isHttps?'Secure':'Insecure',cls:d.isHttps?'ok':'error'},
    {lbl:'Canonical',val:d.canonical?'Set':'Missing',cls:d.canonical?'ok':'warn'},
    {lbl:'Viewport',val:d.viewport?'Set':'Missing',cls:d.viewport?'ok':'error'},
    {lbl:'Schema',val:`${d.structuredData.length} found`,cls:d.structuredData.length>0?'ok':'warn'},
  ].map(c=>{
    if(c.cls==='error'){
      return `<div style="background:#ef4444;border:2px solid #b91c1c;border-radius:10px;padding:10px 8px;text-align:center;box-shadow:0 3px 10px rgba(239,68,68,0.3)">
        <div style="font-size:1rem;margin-bottom:3px">❌</div>
        <div style="font-size:0.58rem;font-weight:800;text-transform:uppercase;letter-spacing:.4px;color:rgba(255,255,255,0.8);margin-bottom:3px">${c.lbl}</div>
        <div style="font-size:0.8rem;font-weight:900;color:#fff">${c.val}</div>
      </div>`;
    }
    const bg={ok:'#f0fdf4',warn:'#fff7ed'};
    const brd={ok:'#86efac',warn:'#fb923c'};
    const hd={ok:'#14532d',warn:'#7c2d12'};
    const ico={ok:'✅',warn:'⚠️'};
    return `<div style="background:${bg[c.cls]};border:2px solid ${brd[c.cls]};border-radius:10px;padding:10px 8px;text-align:center">
      <div style="font-size:1rem;margin-bottom:3px">${ico[c.cls]}</div>
      <div style="font-size:0.58rem;font-weight:700;text-transform:uppercase;letter-spacing:.4px;color:${hd[c.cls]};margin-bottom:3px">${c.lbl}</div>
      <div style="font-size:0.8rem;font-weight:900;color:${hd[c.cls]}">${c.val}</div>
    </div>`;
  }).join('')}
</div>

<!-- ═══════════════════
     SECTION 1: ERRORS
═══════════════════ -->
<div class="section">
  ${secHead('❌','Critical Errors','Issues that directly prevent ranking — fix these first')}
  ${errors.length===0
    ? `<div style="background:#f0fdf4;border:2px solid #86efac;border-radius:14px;padding:22px 24px;display:flex;align-items:center;gap:16px">
        <span style="font-size:2rem">🎉</span>
        <div><div style="font-size:1rem;font-weight:800;color:#166534">Zero Critical Errors!</div>
        <div style="font-size:0.78rem;color:#15803d;margin-top:3px">Your page passes all critical SEO checks — excellent foundation</div></div>
      </div>`
    : errors.map((e,i)=>`
      <div class="error-card">
        <div class="error-card-head">
          <div style="width:26px;height:26px;background:rgba(0,0,0,0.2);border:2px solid rgba(255,255,255,0.4);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.78rem;font-weight:900;color:#fff;flex-shrink:0">${i+1}</div>
          <span style="flex:1">${esc(e.text)}</span>
          <span style="background:rgba(0,0,0,0.2);color:#fff;font-size:0.62rem;font-weight:800;padding:3px 10px;border-radius:20px;white-space:nowrap">🔴 CRITICAL</span>
        </div>
        <div class="error-card-body">
          <strong>💡 How to fix:</strong> ${esc(getFixTip(e.text))}
        </div>
      </div>`).join('')}
</div>

<!-- ═══════════════════
     SECTION 2: WARNINGS
═══════════════════ -->
${warns.length>0?`
<div class="section">
  ${secHead('⚠️','Warnings','These improvements will significantly boost your rankings')}
  ${warns.map((w,i)=>`
    <div class="warn-card">
      <div class="warn-card-head">
        <div style="width:26px;height:26px;background:rgba(0,0,0,0.15);border:2px solid rgba(255,255,255,0.4);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:0.72rem;font-weight:900;color:#fff;flex-shrink:0">${i+1}</div>
        <span style="flex:1">${esc(w.text)}</span>
        <span style="background:rgba(0,0,0,0.15);color:#fff;font-size:0.62rem;font-weight:800;padding:3px 10px;border-radius:20px;white-space:nowrap">🟠 MEDIUM</span>
      </div>
      <div class="warn-card-body">
        <strong>💡 Fix:</strong> ${esc(getFixTip(w.text))}
      </div>
    </div>`).join('')}
</div>`:''}

<!-- ═════════════════════════
     SECTION 3: ON-PAGE SEO
═════════════════════════ -->
<div class="section">
  ${secHead('📝','On-Page SEO — Full Analysis','Every on-page element inspected and graded')}

  <!-- Title Tag deep-dive -->
  <div class="blue-box" style="margin-bottom:16px">
    <div class="blue-box-header">📝 TITLE TAG &nbsp;<span style="opacity:0.7;font-weight:400">${tl} characters</span>
      <span style="margin-left:auto">${!d.titleTag?'❌ Missing':tl>=30&&tl<=60?`✅ ${tl} chars — Perfect`:`⚠ ${tl} chars — ${tl<30?'Too Short':'Too Long'}`}</span>
    </div>
    <div class="blue-box-body">
      <div style="background:#fff;border:1.5px solid #dbeafe;border-radius:8px;padding:14px;font-size:0.9rem;color:${d.titleTag?'#111827':'#9ca3af'};font-style:${d.titleTag?'normal':'italic'};line-height:1.5;margin-bottom:12px">${d.titleTag?esc(d.titleTag):'⚠ No title tag found on this page'}</div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
        <span style="font-size:0.65rem;color:#9ca3af;width:28px;text-align:right;flex-shrink:0">0</span>
        <div style="flex:1">${bar(tl?Math.min(100,(tl/60)*100):0, !d.titleTag?'#ef4444':tl>=30&&tl<=60?'#3B5DD4':'#F97316', 10)}</div>
        <span style="font-size:0.65rem;color:#9ca3af;width:28px;flex-shrink:0">60</span>
      </div>
      <div style="text-align:center;font-size:0.68rem;color:#6b7280">Ideal range: <strong style="color:#3B5DD4">30 – 60 characters</strong>  ·  Current: <strong>${tl}</strong> chars</div>
    </div>
  </div>

  <!-- Meta Description deep-dive -->
  <div class="blue-box" style="margin-bottom:16px">
    <div class="blue-box-header">📋 META DESCRIPTION &nbsp;<span style="opacity:0.7;font-weight:400">${dl} characters</span>
      <span style="margin-left:auto">${!d.description?'❌ Missing':dl>=70&&dl<=160?`✅ ${dl} chars — Good`:`⚠ ${dl} chars — ${dl<70?'Too Short':'Too Long'}`}</span>
    </div>
    <div class="blue-box-body">
      <div style="background:#fff;border:1.5px solid #dbeafe;border-radius:8px;padding:14px;font-size:0.88rem;color:${d.description?'#374151':'#9ca3af'};font-style:${d.description?'normal':'italic'};line-height:1.7;margin-bottom:12px">${d.description?esc(d.description):'⚠ No meta description — add one to improve search click-through rates'}</div>
      <div style="display:flex;align-items:center;gap:10px;margin-bottom:6px">
        <span style="font-size:0.65rem;color:#9ca3af;width:28px;text-align:right;flex-shrink:0">0</span>
        <div style="flex:1">${bar(dl?Math.min(100,(dl/160)*100):0, !d.description?'#ef4444':dl>=70&&dl<=160?'#3B5DD4':'#F97316', 10)}</div>
        <span style="font-size:0.65rem;color:#9ca3af;width:28px;flex-shrink:0">160</span>
      </div>
      <div style="text-align:center;font-size:0.68rem;color:#6b7280">Ideal range: <strong style="color:#3B5DD4">70 – 160 characters</strong>  ·  Current: <strong>${dl}</strong> chars</div>
    </div>
  </div>

  <!-- Meta Details Grid -->
  <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
    ${[
      {icon:'🌐',lbl:'Canonical URL',val:d.canonical||'Not set',cls:d.canonical?'ok':'warn'},
      {icon:'🤖',lbl:'Robots Directive',val:d.robots||'index, follow (default)',cls:d.isNoindex?'error':'ok'},
      {icon:'🚫',lbl:'Noindex Status',val:d.isNoindex?'NOINDEX — Hidden from Google':'Indexable — Visible in search',cls:d.isNoindex?'error':'ok'},
      {icon:'🌍',lbl:'HTML Language',val:d.lang||'Not declared',cls:d.lang?'ok':'warn'},
      {icon:'📱',lbl:'Mobile Viewport',val:d.viewport||'MISSING',cls:d.viewport?'ok':'error'},
      {icon:'🔑',lbl:'Keywords Meta',val:d.keywords||'(not set)',cls:'neutral'},
      {icon:'👤',lbl:'Author',val:d.author||'(not set)',cls:'neutral'},
      {icon:'🔤',lbl:'Charset',val:d.charset||'Not declared',cls:'neutral'},
      {icon:'⭐',lbl:'Favicon',val:d.favicon?'Present':'Missing',cls:d.favicon?'ok':'warn'},
      {icon:'📄',lbl:'Doctype',val:d.doctype||'Missing',cls:d.doctype==='HTML'?'ok':'warn'},
    ].map(r=>{
      const bcol={ok:'#f0fdf4',warn:'#fff7ed',error:'#ef4444',neutral:'#fff'};
      const tcol={ok:'#14532d',warn:'#7c2d12',error:'#fff',neutral:'#1e3a8a'};
      const brd ={ok:'#86efac',warn:'#fb923c',error:'#b91c1c',neutral:'#3B5DD4'};
      const blft={ok:'4px solid #16a34a',warn:'4px solid #F97316',error:'6px solid #b91c1c',neutral:'4px solid #3B5DD4'};
      const ico ={ok:'✅',warn:'⚠️',error:'❌',neutral:'ℹ️'};
      const valCol={ok:'#15803d',warn:'#9a3412',error:'#fff',neutral:'#374151'};
      return `<div style="background:${bcol[r.cls]};border:2px solid ${brd[r.cls]};border-left:${blft[r.cls]};border-radius:12px;padding:14px 16px;display:flex;align-items:flex-start;gap:10px;${r.cls==='error'?'box-shadow:0 3px 10px rgba(239,68,68,0.25)':''}">
        <span style="font-size:1.1rem;flex-shrink:0">${r.icon}</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:0.62rem;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:${tcol[r.cls]};margin-bottom:4px">${r.lbl}</div>
          <div style="font-size:0.8rem;font-weight:600;color:${valCol[r.cls]};overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(String(r.val))}">${esc(String(r.val).slice(0,55)+(String(r.val).length>55?'…':''))}</div>
        </div>
        <span style="font-size:1.1rem;flex-shrink:0">${ico[r.cls]}</span>
      </div>`;
    }).join('')}
  </div>
</div>

<!-- ═══════════════════════
     SECTION 4: HEADINGS
═══════════════════════ -->
<div class="section">
  ${secHead('📋','Heading Structure','H1–H6 hierarchy analysis for content & SEO')}

  <!-- heading count badges -->
  <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:20px">
    ${[1,2,3,4,5,6].map(n=>{
      const c=hdCounts[n];
      if(n>4&&c===0)return '';
      const bg=n===1&&c===0?'#fff5f5':n===1&&c>1?'#fffbeb':n===1?'#f0fdf4':n===2?'#fffbeb':'#f8faff';
      const brd=n===1&&c===0?'#fca5a5':n===1&&c>1?'#fde68a':n===1?'#86efac':n===2?'#fde68a':'#c7d2fe';
      const hcol=n===1&&c===0?'#c62828':n===1&&c>1?'#b45309':n===1?'#166534':n===2?'#b45309':'#2B5BCD';
      return `<div style="background:${bg};border:2px solid ${brd};border-radius:12px;padding:12px 20px;text-align:center;min-width:68px">
        <div style="font-family:monospace;font-size:0.75rem;font-weight:800;color:${hcol}">H${n}</div>
        <div style="font-size:1.6rem;font-weight:900;color:${hcol};line-height:1.1">${c}</div>
        <div style="font-size:0.58rem;color:${hcol};opacity:0.7;margin-top:2px">${n===1?c===1?'Perfect':c===0?'Missing':'Too many':c===0?'None':'found'}</div>
      </div>`;
    }).join('')}
  </div>

  ${d.headings.length>0?`
  <table>
    <thead><tr><th style="width:60px">Level</th><th>Heading Text</th></tr></thead>
    <tbody>
      ${d.headings.slice(0,30).map(h=>`
      <tr>
        <td>
          <span style="background:${h.level===1?'linear-gradient(135deg,#2B5BCD,#1e3a8a)':h.level===2?'linear-gradient(135deg,#FEB622,#b45309)':'#e8eaf6'};
            color:${h.level<=2?'#fff':'#374151'};font-family:monospace;font-size:0.7rem;font-weight:800;
            padding:4px 10px;border-radius:6px;display:inline-block">H${h.level}</span>
        </td>
        <td style="font-weight:${h.level===1?'800':'500'};color:${h.level===1?'#2B5BCD':h.level===2?'#374151':'#6b7280'};padding-left:${(h.level-1)*14}px">
          ${esc(h.text)}
        </td>
      </tr>`).join('')}
      ${d.headings.length>30?`<tr><td colspan="2" style="text-align:center;color:#9ca3af;font-style:italic;padding:12px">… and ${d.headings.length-30} more headings</td></tr>`:''}
    </tbody>
  </table>`
  :'<div style="text-align:center;padding:30px;color:#9ca3af;font-size:0.85rem">No headings found on this page</div>'}
</div>

<!-- ═════════════════════════════
     SECTION 5: OPEN GRAPH & SOCIAL
═════════════════════════════ -->
<div class="section">
  ${secHead('📣','Open Graph & Social Media Tags','Controls how your page appears when shared on social platforms')}

  <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:20px">
    ${[
      ['og:title',d.openGraph['og:title'],'Facebook / LinkedIn title'],
      ['og:description',d.openGraph['og:description'],'Social sharing description'],
      ['og:image',d.openGraph['og:image'],'1200×630px recommended'],
      ['og:url',d.openGraph['og:url'],'Canonical social URL'],
      ['og:type',d.openGraph['og:type'],'website / article / product'],
      ['og:site_name',d.openGraph['og:site_name'],'Brand name for sharing'],
      ['twitter:card',d.twitter['twitter:card'],'summary / summary_large_image'],
      ['twitter:title',d.twitter['twitter:title'],'Twitter/X card title'],
      ['twitter:description',d.twitter['twitter:description'],'Twitter/X card description'],
      ['twitter:image',d.twitter['twitter:image'],'Twitter/X card image'],
    ].map(([k,v,hint])=>v
      ? `<div style="background:#fff;border:2px solid #3B5DD4;border-left:5px solid #1e3a8a;border-radius:10px;padding:12px;display:flex;gap:10px;align-items:flex-start">
          <span style="font-size:1rem;flex-shrink:0">✅</span>
          <div style="flex:1;min-width:0">
            <div style="font-family:monospace;font-size:0.67rem;font-weight:800;color:#1e3a8a;margin-bottom:3px">${esc(k)}</div>
            <div style="font-size:0.75rem;font-weight:600;color:#111827;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${esc(String(v).slice(0,65)+(v.length>65?'…':''))}</div>
          </div>
        </div>`
      : `<div style="background:#fff7ed;border:2px solid #F97316;border-left:5px solid #c2580a;border-radius:10px;padding:12px;display:flex;gap:10px;align-items:flex-start">
          <span style="font-size:1rem;flex-shrink:0">⚠️</span>
          <div style="flex:1;min-width:0">
            <div style="font-family:monospace;font-size:0.67rem;font-weight:800;color:#c2580a;margin-bottom:3px">${esc(k)}</div>
            <div style="font-size:0.75rem;color:#9ca3af;font-style:italic">not set — ${hint}</div>
          </div>
        </div>`
    ).join('')}
  </div>

  <!-- OG preview mockup -->
  ${d.openGraph['og:title']?`
  <div style="background:#fff;border:2px solid #3B5DD4;border-radius:14px;padding:16px;margin-top:8px">
    <div style="font-size:0.65rem;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:.5px;margin-bottom:10px">📱 Social Share Preview</div>
    <div style="background:#fff;border:2px solid #3B5DD4;border-radius:10px;overflow:hidden;max-width:500px">
      ${d.openGraph['og:image']?`<div style="height:50px;background:linear-gradient(135deg,#2B5BCD,#FEB622);display:flex;align-items:center;justify-content:center;font-size:0.7rem;color:rgba(255,255,255,0.7)">[OG Image: ${esc(d.openGraph['og:image'].split('/').pop().slice(0,40))}]</div>`:''}
      <div style="padding:12px 14px">
        <div style="font-size:0.68rem;color:#9ca3af;text-transform:uppercase;margin-bottom:4px">${esc(d.host||'')}</div>
        <div style="font-weight:800;color:#111827;font-size:0.88rem;margin-bottom:4px">${esc((d.openGraph['og:title']||'').slice(0,65))}</div>
        <div style="font-size:0.78rem;color:#6b7280;line-height:1.4">${esc((d.openGraph['og:description']||'').slice(0,120))}</div>
      </div>
    </div>
  </div>`:''}
</div>

<!-- ════════════════════
     SECTION 6: SPEED
════════════════════ -->
<div class="section">
  ${secHead('⚡','Page Speed & Core Web Vitals','Performance data from your browser session')}

  <div style="display:flex;gap:24px;align-items:center;background:#fff;border:2px solid #3B5DD4;border-radius:14px;padding:20px;margin-bottom:20px">
    <div style="position:relative;width:110px;height:110px;flex-shrink:0">
      ${ring(speedScore,100,speedCol,110)}
      <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
        <div style="font-size:1.8rem;font-weight:900;color:${speedCol}">${speedScore}</div>
        <div style="font-size:0.52rem;font-weight:800;color:#9ca3af;text-transform:uppercase;letter-spacing:1.5px">SPEED</div>
      </div>
    </div>
    <div style="flex:1">
      <div style="font-size:1.2rem;font-weight:900;color:${speedCol};margin-bottom:6px">${speedLbl}</div>
      <div style="display:grid;grid-template-columns:1fr 1fr 1fr;gap:8px">
        ${[
          {lbl:'TTFB',v:d.ttfb,suf:'ms',good:200,bad:600},
          {lbl:'DOM Ready',v:d.domContentLoaded,suf:'ms',good:1500,bad:3000},
          {lbl:'Full Load',v:d.loadTime,suf:'ms',good:3000,bad:6000},
        ].map(m=>{
          const cls=m.v==null?'neutral':m.v<=m.good?'ok':m.v<=m.bad?'warn':'error';
          const col={ok:'#166534',warn:'#b45309',error:'#c62828',neutral:'#6b7280'};
          const bg={ok:'#f0fdf4',warn:'#fffbeb',error:'#fff5f5',neutral:'#f1f5f9'};
          return `<div style="background:${bg[cls]};border-radius:8px;padding:8px;text-align:center">
            <div style="font-size:0.58rem;font-weight:700;color:#9ca3af;text-transform:uppercase;letter-spacing:.4px">${m.lbl}</div>
            <div style="font-size:1.1rem;font-weight:900;color:${col[cls]}">${m.v!=null?m.v+m.suf:'N/A'}</div>
          </div>`;
        }).join('')}
      </div>
    </div>
  </div>

  <table>
    <thead><tr><th>Performance Metric</th><th>Value</th><th>Target</th><th>Status</th><th>SEO Impact</th></tr></thead>
    <tbody>
      ${[
        {m:'TTFB (Time to First Byte)',v:d.ttfb!=null?d.ttfb+'ms':'N/A',cls:d.ttfb==null?'neutral':d.ttfb<200?'ok':d.ttfb<600?'warn':'error',tgt:'< 200ms',imp:'⭐⭐⭐ Server speed, Core Web Vital'},
        {m:'DOM Content Loaded',v:d.domContentLoaded!=null?d.domContentLoaded+'ms':'N/A',cls:d.domContentLoaded==null?'neutral':d.domContentLoaded<1500?'ok':d.domContentLoaded<3000?'warn':'error',tgt:'< 1 500ms',imp:'⭐⭐⭐ Interactivity'},
        {m:'Full Page Load Time',v:d.loadTime!=null?d.loadTime+'ms':'N/A',cls:d.loadTime==null?'neutral':d.loadTime<3000?'ok':d.loadTime<6000?'warn':'error',tgt:'< 3 000ms',imp:'⭐⭐⭐ User experience & bounce rate'},
        {m:'JavaScript Files',v:d.scriptCount!=null?d.scriptCount:0,cls:d.scriptCount<20?'ok':d.scriptCount<40?'warn':'error',tgt:'< 20',imp:'⭐⭐ Parse & execute overhead'},
        {m:'CSS Stylesheets',v:d.styleCount!=null?d.styleCount:0,cls:d.styleCount<5?'ok':d.styleCount<10?'warn':'error',tgt:'< 5',imp:'⭐⭐ Render-blocking potential'},
        {m:'Total Images',v:d.images.length,cls:'neutral',tgt:'Optimise each',imp:'⭐⭐⭐ Affects LCP (Largest Contentful Paint)'},
        {m:'Lazy Loaded Images',v:d.imagesLazy,cls:d.imagesLazy>0||d.images.length<=3?'ok':'warn',tgt:'All non-hero images',imp:'⭐⭐ Reduces initial page weight'},
        {m:'Images Missing Alt Text',v:d.imagesMissing,cls:d.imagesMissing===0?'ok':'warn',tgt:'0 missing',imp:'⭐⭐ Accessibility + image SEO'},
      ].map(r=>{
        const ico={ok:'✅',warn:'⚠️',error:'❌',neutral:'ℹ️'};
        return `<tr class="row-${r.cls}"><td style="font-weight:600">${r.m}</td><td class="${r.cls}" style="font-family:monospace;font-weight:800">${r.v}</td><td style="color:#6b7280;font-size:0.78rem">${r.tgt}</td><td style="text-align:center;font-size:1rem">${ico[r.cls]}</td><td style="font-size:0.75rem;color:#6b7280">${r.imp}</td></tr>`;
      }).join('')}
    </tbody>
  </table>

  <!-- Core Web Vitals cards -->
  <div style="margin-top:16px;display:grid;grid-template-columns:repeat(3,1fr);gap:10px">
    ${[
      {lbl:'LCP',full:'Largest Contentful Paint',est:d.loadTime!=null?'~'+d.loadTime+'ms':'Run PSI',tgt:'< 2 500ms',cls:d.loadTime!=null?d.loadTime<2500?'ok':d.loadTime<4000?'warn':'error':'neutral'},
      {lbl:'FID / INP',full:'Interaction to Next Paint',est:'Browser only',tgt:'< 200ms',cls:'neutral'},
      {lbl:'CLS',full:'Cumulative Layout Shift',est:'Run PageSpeed Insights',tgt:'< 0.1',cls:'neutral'},
      {lbl:'FCP',full:'First Contentful Paint',est:d.domContentLoaded!=null?'~'+d.domContentLoaded+'ms':'Run PSI',tgt:'< 1 800ms',cls:d.domContentLoaded!=null?d.domContentLoaded<1800?'ok':d.domContentLoaded<3000?'warn':'error':'neutral'},
      {lbl:'TTFB',full:'Time to First Byte',est:d.ttfb!=null?d.ttfb+'ms':'N/A',tgt:'< 200ms',cls:d.ttfb!=null?d.ttfb<200?'ok':d.ttfb<600?'warn':'error':'neutral'},
      {lbl:'DOM Ready',full:'DOMContentLoaded',est:d.domContentLoaded!=null?d.domContentLoaded+'ms':'N/A',tgt:'< 1 500ms',cls:d.domContentLoaded!=null?d.domContentLoaded<1500?'ok':d.domContentLoaded<3000?'warn':'error':'neutral'},
    ].map(c=>{
      const bg={ok:'#f0fdf4',warn:'#fffbeb',error:'#fff5f5',neutral:'#f8faff'};
      const brd={ok:'#86efac',warn:'#fde68a',error:'#fca5a5',neutral:'#c7d2fe'};
      const hcol={ok:'#166534',warn:'#b45309',error:'#c62828',neutral:'#2B5BCD'};
      return `<div style="background:${bg[c.cls]};border:2px solid ${brd[c.cls]};border-top:4px solid ${brd[c.cls]};border-radius:12px;padding:14px;text-align:center">
        <div style="font-family:monospace;font-size:0.82rem;font-weight:900;color:${hcol[c.cls]};margin-bottom:2px">${c.lbl}</div>
        <div style="font-size:1.1rem;font-weight:900;color:${hcol[c.cls]};margin:6px 0">${c.est}</div>
        <div style="font-size:0.6rem;color:#9ca3af;margin-bottom:3px">Target: ${c.tgt}</div>
        <div style="font-size:0.68rem;color:#6b7280">${c.full}</div>
      </div>`;
    }).join('')}
  </div>

  <div style="margin-top:14px;display:flex;gap:10px">
    <a href="https://pagespeed.web.dev/report?url=${encodeURIComponent('https://'+d.host)}" target="_blank"
      style="flex:1;background:linear-gradient(90deg,#2B5BCD,#1e3a8a);color:#fff;padding:12px;border-radius:10px;text-align:center;font-weight:800;font-size:0.82rem;text-decoration:none">
      ⚡ Open in PageSpeed Insights →
    </a>
    <a href="https://gtmetrix.com/?url=${encodeURIComponent('https://'+d.host)}" target="_blank"
      style="flex:1;background:#fff;color:#2B5BCD;border:2px solid #2B5BCD;padding:12px;border-radius:10px;text-align:center;font-weight:800;font-size:0.82rem;text-decoration:none">
      🚀 Test on GTmetrix →
    </a>
  </div>
</div>

<!-- ════════════════════
     SECTION 7: LINKS
════════════════════ -->
<div class="section">
  ${secHead('🔗','Links Analysis','Internal linking structure, external links and anchor text audit')}

  <!-- summary tiles -->
  <div style="display:grid;grid-template-columns:repeat(5,1fr);gap:10px;margin-bottom:20px">
    ${[
      {n:d.links.length,lbl:'Total Links',icon:'🔗',bg:'#eff4ff',brd:'#c7d2fe',col:'#2B5BCD'},
      {n:d.internalLinks.length,lbl:'Internal',icon:'🏠',bg:'#f0fdf4',brd:'#86efac',col:'#166534'},
      {n:d.externalLinks.length,lbl:'External',icon:'🌐',bg:'#f5f3ff',brd:'#ddd6fe',col:'#5b21b6'},
      {n:d.nofollowLinks.length,lbl:'Nofollow',icon:'🚫',bg:d.nofollowLinks.length>0?'#fffbeb':'#f0fdf4',brd:d.nofollowLinks.length>0?'#fde68a':'#86efac',col:d.nofollowLinks.length>0?'#b45309':'#166534'},
      {n:d.internalLinks.filter(l=>!l.text||l.text.trim().length<2).length,lbl:'No Anchor',icon:'⚠️',bg:'#fffbeb',brd:'#fde68a',col:'#b45309'},
    ].map(s=>`
    <div style="background:${s.bg};border:2px solid ${s.brd};border-radius:12px;padding:14px 10px;text-align:center">
      <div style="font-size:1.3rem;margin-bottom:4px">${s.icon}</div>
      <div style="font-size:1.5rem;font-weight:900;color:${s.col};line-height:1">${s.n}</div>
      <div style="font-size:0.6rem;font-weight:700;text-transform:uppercase;color:${s.col};opacity:.7;letter-spacing:.4px;margin-top:3px">${s.lbl}</div>
    </div>`).join('')}
  </div>

  ${d.internalLinks.length>0?`
  <div style="margin-bottom:8px;font-size:0.78rem;font-weight:800;color:#2B5BCD;border-bottom:2px solid #FEB622;padding-bottom:6px;display:inline-block">Internal Links (${Math.min(d.internalLinks.length,20)} of ${d.internalLinks.length})</div>
  <table style="margin-bottom:16px">
    <thead><tr><th>#</th><th>Anchor Text</th><th>URL Path</th><th>Rel</th></tr></thead>
    <tbody>
      ${d.internalLinks.slice(0,20).map((l,i)=>{
        let path='';try{path=new URL(l.href).pathname;}catch(e){path=l.href;}
        const noAnchor=!l.text||l.text.trim().length<2;
        return `<tr>
          <td style="color:#9ca3af;width:30px">${i+1}</td>
          <td style="${noAnchor?'color:#9ca3af;font-style:italic':'font-weight:600;color:#111827'}">${noAnchor?'(no anchor text)':esc(l.text.slice(0,60))}</td>
          <td class="mono" style="font-size:0.78rem;color:#2B5BCD"><a href="${esc(l.href)}" target="_blank" style="color:#2B5BCD">${esc(path.slice(0,55)+(path.length>55?'…':''))}</a></td>
          <td>${l.nofollow?statusChip('warn','nofollow'):statusChip('ok','dofollow')}</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>`:''}

  ${d.externalLinks.length>0?`
  <div style="margin-bottom:8px;font-size:0.78rem;font-weight:800;color:#2B5BCD;border-bottom:2px solid #FEB622;padding-bottom:6px;display:inline-block">External Links (${Math.min(d.externalLinks.length,15)} of ${d.externalLinks.length})</div>
  <table>
    <thead><tr><th>#</th><th>Anchor Text</th><th>Destination</th><th>Type</th></tr></thead>
    <tbody>
      ${d.externalLinks.slice(0,15).map((l,i)=>`
      <tr>
        <td style="color:#9ca3af;width:30px">${i+1}</td>
        <td style="font-weight:600">${esc((l.text||'no anchor').slice(0,50))}</td>
        <td class="mono" style="font-size:0.76rem;color:#2B5BCD"><a href="${esc(l.href)}" target="_blank" style="color:#2B5BCD">${esc(l.href.slice(0,60)+(l.href.length>60?'…':''))}</a></td>
        <td>${l.nofollow?statusChip('warn','nofollow'):statusChip('ok','dofollow')}</td>
      </tr>`).join('')}
    </tbody>
  </table>`:''}
</div>

<!-- ════════════════════
     SECTION 8: IMAGES
════════════════════ -->
<div class="section">
  ${secHead('🖼️','Images Audit','Alt text, lazy loading and filename optimisation')}

  <div style="display:grid;grid-template-columns:repeat(4,1fr);gap:10px;margin-bottom:20px">
    ${[
      {n:d.images.length,lbl:'Total Images',bg:'#eff4ff',brd:'#c7d2fe',col:'#2B5BCD'},
      {n:d.imagesWithAlt,lbl:'Have Alt Text',bg:'#f0fdf4',brd:'#86efac',col:'#166534'},
      {n:d.imagesMissing,lbl:'Missing Alt',bg:d.imagesMissing>0?'#fff5f5':'#f0fdf4',brd:d.imagesMissing>0?'#fca5a5':'#86efac',col:d.imagesMissing>0?'#c62828':'#166534'},
      {n:d.imagesLazy,lbl:'Lazy Loaded',bg:d.imagesLazy>0?'#f0fdf4':'#fffbeb',brd:d.imagesLazy>0?'#86efac':'#fde68a',col:d.imagesLazy>0?'#166534':'#b45309'},
    ].map(s=>`
    <div style="background:${s.bg};border:2px solid ${s.brd};border-radius:12px;padding:14px;text-align:center">
      <div style="font-size:1.6rem;font-weight:900;color:${s.col}">${s.n}</div>
      <div style="font-size:0.62rem;font-weight:700;text-transform:uppercase;color:${s.col};opacity:.7;letter-spacing:.4px;margin-top:3px">${s.lbl}</div>
    </div>`).join('')}
  </div>

  ${d.images.length>0?`
  <table>
    <thead><tr><th>#</th><th>File Name</th><th>Alt Text</th><th>Load</th><th>srcset</th><th>Status</th></tr></thead>
    <tbody>
      ${d.images.slice(0,20).map((img,i)=>{
        const hasAlt=img.hasAlt&&!img.altEmpty;
        const file=(img.src||'').split('/').pop().split('?')[0].slice(0,38)||'unknown';
        return `<tr class="${hasAlt?'row-ok':'row-error'}">
          <td style="color:#9ca3af;width:30px">${i+1}</td>
          <td class="mono" style="font-size:0.75rem">${esc(file)}</td>
          <td style="${hasAlt?'':'color:#b91c1c;font-weight:700;font-style:italic'}">${hasAlt?esc((img.alt||'').slice(0,55)):'❌ Missing alt text'}</td>
          <td style="font-size:0.75rem">${img.loading==='lazy'?'<span style="color:#3B5DD4;font-weight:700">⚡ lazy</span>':'<span style="color:#9ca3af">eager</span>'}</td>
          <td style="font-size:0.75rem">${img.srcset?'<span style="color:#15803d;font-weight:700">✓</span>':'<span style="color:#9ca3af">—</span>'}</td>
          <td>${hasAlt?statusChip('ok','✅ OK'):statusChip('error','❌ Fix')}</td>
        </tr>`;
      }).join('')}
      ${d.images.length>20?`<tr><td colspan="6" style="text-align:center;color:#9ca3af;font-style:italic">… and ${d.images.length-20} more images</td></tr>`:''}
    </tbody>
  </table>`:'<div style="text-align:center;padding:24px;color:#9ca3af">No images found on this page</div>'}
</div>

<!-- ═══════════════════════════
     SECTION 9: KEYWORD DENSITY
═══════════════════════════ -->
${kd.length>0?`
<div class="section">
  ${secHead('🔑','Keyword Density Analysis',`Extracted from ${d.wordCount.toLocaleString()} words of page content`)}

  <div style="background:#fff;border:2px solid #3B5DD4;border-radius:12px;padding:14px 18px;margin-bottom:16px;font-size:0.78rem;color:#374151;line-height:1.7">
    <strong style="color:#2B5BCD">📊 How to read this table:</strong>
    Density <span style="color:#166534;font-weight:700">1–3%</span> = ideal for your primary keywords.
    <span style="color:#b45309;font-weight:700">3–4%</span> = borderline — monitor carefully.
    <span style="color:#c62828;font-weight:700">&gt; 4%</span> = potential keyword stuffing — reduce usage.
  </div>

  <table>
    <thead><tr><th style="width:30px">#</th><th>Keyword</th><th>Count</th><th>Density</th><th style="width:180px">Distribution</th><th>Verdict</th><th>Recommendation</th></tr></thead>
    <tbody>
      ${kd.slice(0,15).map((k,i)=>{
        const pct=Math.min(100,(k.count/kd[0].count)*100);
        const d2=parseFloat(k.density);
        const cls=d2>4?'error':d2>2?'warn':'ok';
        const verdict=d2>4?'⚠️ Over-used':d2>1.5?'✅ Ideal':d2>0.5?'ℹ️ OK':'💡 Low';
        const rec=d2>4?'Reduce — spread synonyms throughout content':d2>1.5?'Perfect keyword frequency':d2>0.5?'Acceptable — could add more uses':'Consider using this keyword more';
        const barCol=d2>4?'#ef4444':d2>2?'#FEB622':'#2B5BCD';
        return `<tr>
          <td style="color:#9ca3af;font-weight:700">${i+1}</td>
          <td style="font-weight:900;color:#2B5BCD;font-size:0.92rem">${esc(k.word)}</td>
          <td class="mono" style="font-weight:700">${k.count}×</td>
          <td class="${cls}" style="font-family:monospace;font-size:0.9rem;font-weight:900">${k.density}%</td>
          <td><div style="background:#e8eaf6;border-radius:5px;height:12px;overflow:hidden">
            <div style="height:100%;width:${pct}%;background:${barCol};border-radius:5px"></div>
          </div></td>
          <td style="font-size:0.82rem">${verdict}</td>
          <td style="font-size:0.72rem;color:#6b7280">${rec}</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>
</div>`:''}

<!-- ══════════════════════════════
     SECTION 10: STRUCTURED DATA
══════════════════════════════ -->
<div class="section">
  ${secHead('📊','Structured Data & Schema Markup','JSON-LD rich snippets — how Google understands your content')}

  ${d.structuredData.length>0?`
  <!-- Summary stat bar -->
  <div style="display:flex;gap:10px;margin-bottom:20px;flex-wrap:wrap">
    <div style="background:#eff4ff;border:2px solid #3B5DD4;border-radius:12px;padding:14px 22px;text-align:center;flex:1;min-width:110px">
      <div style="font-size:1.8rem;font-weight:900;color:#1e3a8a;line-height:1">${d.structuredData.length}</div>
      <div style="font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#3B5DD4;margin-top:3px">Schema Found</div>
    </div>
    <div style="background:#f0fdf4;border:2px solid #86efac;border-radius:12px;padding:14px 22px;text-align:center;flex:1;min-width:110px">
      <div style="font-size:1.8rem;font-weight:900;color:#16a34a;line-height:1">✓</div>
      <div style="font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#15803d;margin-top:3px">Valid JSON-LD</div>
    </div>
    <div style="background:#fff7ed;border:2px solid #fb923c;border-radius:12px;padding:14px 22px;text-align:center;flex:1;min-width:110px">
      <div style="font-size:1.8rem;font-weight:900;color:#ea580c;line-height:1">${d.structuredData.map(s=>Object.keys(s).filter(k=>k!=='@context'&&k!=='@type').length).reduce((a,b)=>a+b,0)}</div>
      <div style="font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#c2580a;margin-top:3px">Total Properties</div>
    </div>
    <div style="background:#ecfeff;border:2px solid #67e8f9;border-radius:12px;padding:14px 22px;text-align:center;flex:1;min-width:110px">
      <div style="font-size:1rem;font-weight:900;color:#0e7490;line-height:1.2">${d.structuredData.map(s=>s['@type']||'?').join(' · ')}</div>
      <div style="font-size:0.62rem;font-weight:700;text-transform:uppercase;letter-spacing:.5px;color:#0891b2;margin-top:3px">Schema Types</div>
    </div>
  </div>

  <!-- Rich result eligibility chips -->
  <div style="background:#f8faff;border:2px solid #3B5DD4;border-radius:12px;padding:14px 18px;margin-bottom:20px">
    <div style="font-size:0.75rem;font-weight:800;color:#1e3a8a;margin-bottom:10px">🏆 Rich Result Eligibility</div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      ${(()=>{
        const types=d.structuredData.map(s=>(s['@type']||'').toLowerCase());
        const checks=[
          {type:'faqpage',   label:'FAQ Accordion',   icon:'❓', eligible: types.some(t=>t.includes('faq'))},
          {type:'article',   label:'Article Card',    icon:'📰', eligible: types.some(t=>t.includes('article')||t.includes('blogpost'))},
          {type:'product',   label:'Product Stars',   icon:'⭐', eligible: types.some(t=>t.includes('product'))},
          {type:'breadcrumb',label:'Breadcrumbs',     icon:'🧭', eligible: types.some(t=>t.includes('breadcrumb'))},
          {type:'org',       label:'Knowledge Panel', icon:'🏢', eligible: types.some(t=>t.includes('organization')||t.includes('localbusiness'))},
          {type:'event',     label:'Event Cards',     icon:'📅', eligible: types.some(t=>t.includes('event'))},
          {type:'review',    label:'Review Stars',    icon:'⭐', eligible: types.some(t=>t.includes('review')||t.includes('rating'))},
          {type:'howto',     label:'How-To Steps',    icon:'📋', eligible: types.some(t=>t.includes('howto'))},
        ];
        return checks.map(c=>`
          <div style="background:${c.eligible?'#f0fdf4':'#f8faff'};border:2px solid ${c.eligible?'#86efac':'#e2e8f0'};border-radius:8px;padding:8px 14px;display:flex;align-items:center;gap:6px">
            <span style="font-size:1rem">${c.eligible?'✅':'⬜'}</span>
            <div>
              <div style="font-size:0.7rem;font-weight:800;color:${c.eligible?'#166534':'#6b7280'}">${c.label}</div>
              <div style="font-size:0.58rem;color:${c.eligible?'#15803d':'#9ca3af'}">${c.eligible?'Eligible':'Not detected'}</div>
            </div>
          </div>`).join('');
      })()}
    </div>
  </div>

  <!-- Per-schema detailed cards -->
  ${d.structuredData.map((s,idx)=>{
    const type=s['@type']||'Unknown';
    const ctx=s['@context']||'schema.org';
    const props=Object.keys(s).filter(k=>k!=='@context'&&k!=='@type');
    const typeColors={
      Article:'#3B5DD4',BlogPosting:'#3B5DD4',WebPage:'#0891b2',Organization:'#7c3aed',
      LocalBusiness:'#7c3aed',Product:'#ea580c',FAQPage:'#16a34a',BreadcrumbList:'#d97706',
      Event:'#db2777',Review:'#f59e0b',Person:'#6366f1',WebSite:'#0891b2'
    };
    const col=typeColors[type]||'#3B5DD4';
    return `
    <div style="border:2px solid ${col};border-radius:14px;overflow:hidden;margin-bottom:14px;box-shadow:0 2px 10px rgba(0,0,0,0.06)">
      <!-- card header -->
      <div style="background:${col};padding:12px 18px;display:flex;align-items:center;justify-content:space-between">
        <div style="display:flex;align-items:center;gap:10px">
          <div style="background:rgba(255,255,255,0.22);border-radius:8px;padding:6px 12px;font-size:0.9rem;font-weight:900;color:#fff;font-family:monospace">@${esc(type)}</div>
          <div style="font-size:0.72rem;color:rgba(255,255,255,0.75)">Schema #${idx+1} · ${props.length} properties</div>
        </div>
        <div style="background:rgba(255,255,255,0.2);border:1px solid rgba(255,255,255,0.4);border-radius:20px;padding:4px 12px;font-size:0.65rem;font-weight:800;color:#fff">✅ Valid JSON-LD</div>
      </div>
      <!-- property grid -->
      <div style="padding:14px 18px;background:#fff">
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:12px">
          ${props.slice(0,8).map(k=>{
            let raw=s[k];
            let display=typeof raw==='object'?JSON.stringify(raw).substring(0,60)+(JSON.stringify(raw).length>60?'…':''):String(raw).substring(0,80)+(String(raw).length>80?'…':'');
            const isUrl=String(raw).startsWith('http');
            return `<div style="background:#f8faff;border:1px solid #dbeafe;border-radius:8px;padding:8px 12px">
              <div style="font-size:0.58rem;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:${col};margin-bottom:3px">${esc(k)}</div>
              <div style="font-size:0.72rem;font-weight:600;color:#1e3a8a;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(String(raw))}">${isUrl?`<a href="${esc(String(raw))}" style="color:${col}" target="_blank">${esc(display)}</a>`:esc(display)}</div>
            </div>`;
          }).join('')}
          ${props.length>8?`<div style="background:#f1f5f9;border:1px solid #e2e8f0;border-radius:8px;padding:8px 12px;display:flex;align-items:center;justify-content:center"><div style="font-size:0.72rem;font-weight:700;color:#6b7280">+${props.length-8} more properties</div></div>`:''}
        </div>
        <!-- context + raw -->
        <div style="display:flex;align-items:center;justify-content:space-between;padding-top:10px;border-top:1px solid #e2e8f0">
          <div style="font-size:0.68rem;color:#6b7280">Context: <code style="background:#f1f5f9;padding:2px 6px;border-radius:4px;font-size:0.65rem;color:#374151">${esc(ctx)}</code></div>
          <div style="display:flex;gap:6px">
            ${props.includes('url')?`<span style="background:#eff4ff;border:1px solid #3B5DD4;border-radius:6px;padding:3px 10px;font-size:0.62rem;font-weight:700;color:#1e3a8a">🔗 Has URL</span>`:''}
            ${props.includes('name')?`<span style="background:#f0fdf4;border:1px solid #86efac;border-radius:6px;padding:3px 10px;font-size:0.62rem;font-weight:700;color:#166534">✓ Has Name</span>`:''}
            ${props.includes('description')?`<span style="background:#fff7ed;border:1px solid #fb923c;border-radius:6px;padding:3px 10px;font-size:0.62rem;font-weight:700;color:#9a3412">✓ Has Desc</span>`:''}
            ${props.includes('image')?`<span style="background:#faf5ff;border:1px solid #c4b5fd;border-radius:6px;padding:3px 10px;font-size:0.62rem;font-weight:700;color:#5b21b6">🖼 Has Image</span>`:''}
          </div>
        </div>
      </div>
    </div>`;
  }).join('')}

  <!-- Test link -->
  <div style="background:#f0fdf4;border:2px solid #86efac;border-radius:12px;padding:14px 18px;display:flex;align-items:center;justify-content:space-between;margin-top:8px">
    <div>
      <div style="font-size:0.82rem;font-weight:800;color:#166534;margin-bottom:2px">✅ Structured data detected — test in Google Rich Results</div>
      <div style="font-size:0.72rem;color:#15803d">Validate your schema to confirm rich snippet eligibility</div>
    </div>
    <a href="https://search.google.com/test/rich-results?url=${encodeURIComponent(d.url||'')}" target="_blank"
      style="background:#16a34a;color:#fff;font-size:0.72rem;font-weight:800;padding:8px 16px;border-radius:8px;text-decoration:none;white-space:nowrap;flex-shrink:0">
      🔍 Test Rich Results →
    </a>
  </div>`

  /* ─── NO SCHEMA ─── */
  : `
  <div style="background:#fff1f2;border:2px solid #ef4444;border-radius:14px;padding:20px 24px;margin-bottom:16px;display:flex;gap:14px;align-items:flex-start">
    <span style="font-size:2rem;flex-shrink:0">❌</span>
    <div>
      <div style="font-weight:900;color:#7f1d1d;font-size:1rem;margin-bottom:6px">No Structured Data Found</div>
      <div style="font-size:0.82rem;color:#991b1b;line-height:1.7">
        You are missing JSON-LD schema markup. This means Google cannot show <strong>rich results</strong> (stars, FAQs, breadcrumbs, knowledge panel) for your pages in search.
      </div>
    </div>
  </div>

  <!-- What you're missing grid -->
  <div style="margin-bottom:20px">
    <div style="font-size:0.78rem;font-weight:800;color:#1e3a8a;margin-bottom:12px">📋 Rich Results You're Missing Out On</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
      ${[
        {icon:'❓',type:'FAQPage',label:'FAQ Accordion',desc:'Show expandable Q&A directly in Google results — increases CTR by up to 30%',priority:'High'},
        {icon:'🏢',type:'Organization',label:'Knowledge Panel',desc:'Tell Google who you are — triggers business knowledge panel on branded searches',priority:'High'},
        {icon:'🧭',type:'BreadcrumbList',label:'Breadcrumb Trail',desc:'Show your site structure in search results — improves navigation signals',priority:'Medium'},
        {icon:'📄',type:'WebPage',label:'WebPage / Article',desc:'Mark up your content type — helps with content freshness signals',priority:'Medium'},
        {icon:'⭐',type:'Product',label:'Product Stars',desc:'Show price, rating & reviews in SERP — dramatically improves click rates',priority:'High'},
        {icon:'📅',type:'Event',label:'Event Cards',desc:'Get event listings in search — free rich card placement for events',priority:'Low'},
      ].map(r=>`
      <div style="background:#fff;border:2px solid #3B5DD4;border-radius:10px;padding:12px 14px">
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">
          <span style="font-size:1.1rem">${r.icon}</span>
          <div>
            <div style="font-size:0.75rem;font-weight:800;color:#1e3a8a">${r.label}</div>
            <code style="font-size:0.6rem;color:#3B5DD4;background:#eff4ff;padding:1px 5px;border-radius:4px">${r.type}</code>
          </div>
          <span style="margin-left:auto;font-size:0.58rem;font-weight:800;padding:2px 7px;border-radius:10px;background:${r.priority==='High'?'#fee2e2':r.priority==='Medium'?'#fff3e6':'#f0fdf4'};color:${r.priority==='High'?'#7f1d1d':r.priority==='Medium'?'#7c2d12':'#14532d'}">${r.priority}</span>
        </div>
        <div style="font-size:0.68rem;color:#374151;line-height:1.5">${r.desc}</div>
      </div>`).join('')}
    </div>
  </div>

  <!-- Quick-start code snippet -->
  <div style="background:#1e1e2e;border-radius:12px;overflow:hidden;margin-bottom:16px">
    <div style="background:#3B5DD4;padding:10px 16px;display:flex;align-items:center;justify-content:space-between">
      <span style="font-size:0.75rem;font-weight:800;color:#fff">📋 Quick Start — Paste this in your &lt;head&gt;</span>
      <span style="font-size:0.62rem;color:rgba(255,255,255,0.65)">Organization Schema</span>
    </div>
    <pre style="margin:0;padding:16px;font-size:0.72rem;line-height:1.7;color:#e2e8f0;overflow-x:auto;font-family:'Courier New',monospace">&lt;script type="application/ld+json"&gt;
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Your Company Name",
  "url": "${esc(d.url||'https://yoursite.com')}",
  "logo": "https://yoursite.com/logo.png",
  "sameAs": [
    "https://www.facebook.com/yourpage",
    "https://twitter.com/yourhandle"
  ]
}
&lt;/script&gt;</pre>
  </div>

  <div style="background:#fff7ed;border:2px solid #fb923c;border-radius:12px;padding:14px 18px;display:flex;align-items:center;justify-content:space-between">
    <div style="font-size:0.78rem;font-weight:700;color:#7c2d12">⚠ No schema = no rich results. Add JSON-LD today to unlock free SERP features.</div>
    <a href="https://search.google.com/test/rich-results" target="_blank"
      style="background:#F97316;color:#fff;font-size:0.7rem;font-weight:800;padding:7px 14px;border-radius:8px;text-decoration:none;white-space:nowrap;flex-shrink:0;margin-left:12px">
      Schema Tester →
    </a>
  </div>`}
</div>

<!-- ══════════════════════════
     SECTION 11: TECHNICAL SEO
══════════════════════════ -->
<div class="section">
  ${secHead('🔧','Technical SEO Health Check',`Tech health score: ${techH} — complete server &amp; code audit`)}

  <!-- tech health mini-bar -->
  <div style="background:#fff;border:2px solid #3B5DD4;border-radius:12px;padding:16px 20px;margin-bottom:20px;display:flex;align-items:center;gap:20px">
    <div style="position:relative;width:80px;height:80px;flex-shrink:0">
      ${ring(techNum,100,techNum>=80?'#2B5BCD':techNum>=60?'#FEB622':'#ef4444',80)}
      <div style="position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;justify-content:center">
        <div style="font-size:1.1rem;font-weight:900;color:${techNum>=80?'#2B5BCD':techNum>=60?'#FEB622':'#ef4444'}">${techH}</div>
      </div>
    </div>
    <div style="flex:1">
      <div style="font-size:0.9rem;font-weight:900;color:${techNum>=80?'#2B5BCD':techNum>=60?'#b45309':'#c62828'};margin-bottom:4px">
        Technical Health: ${techNum>=80?'Excellent':techNum>=60?'Good':techNum>=40?'Needs Work':'Poor'}
      </div>
      <div style="font-size:0.75rem;color:#6b7280">Based on HTTPS, canonical, viewport, indexability, schema, charset, favicon &amp; doctype</div>
    </div>
  </div>

  <table>
    <thead><tr><th>Technical Check</th><th>Value Detected</th><th>Status</th><th>Priority</th><th>What to Do</th></tr></thead>
    <tbody>
      ${[
        {c:'HTTPS / SSL Certificate',v:d.isHttps?'🔒 Secure':'⚠ Not Secure',cls:d.isHttps?'ok':'error',pri:d.isHttps?'—':'🔴 Critical',tip:d.isHttps?'SSL is active — good':'Install SSL immediately. HTTPS is a Google ranking factor'},
        {c:'Canonical URL',v:d.canonical||'Not set',cls:d.canonical?'ok':'warn',pri:d.canonical?'—':'🟡 Medium',tip:d.canonical?'Prevents duplicate content':'Add <link rel="canonical" href="https://'+d.host+d.url.replace(/^https?:\/\/[^/]+/,'')+'"/>'},
        {c:'Robots / Indexability',v:d.robots||'index, follow (default)',cls:d.isNoindex?'error':'ok',pri:d.isNoindex?'🔴 Critical':'—',tip:d.isNoindex?'REMOVE noindex immediately — page is invisible to Google':'Page is indexable — no action needed'},
        {c:'Noindex Directive',v:d.isNoindex?'YES — BLOCKED':'No — Visible',cls:d.isNoindex?'error':'ok',pri:d.isNoindex?'🔴 Critical':'—',tip:d.isNoindex?'Find and remove noindex from meta robots or X-Robots header':'✓ Page will appear in search results'},
        {c:'Mobile Viewport',v:d.viewport?'✓ '+d.viewport.slice(0,40):'MISSING',cls:d.viewport?'ok':'error',pri:d.viewport?'—':'🔴 Critical',tip:d.viewport?'Good — mobile-friendly viewport declared':'Add <meta name="viewport" content="width=device-width, initial-scale=1">'},
        {c:'HTML Language (lang=)',v:d.lang||'Not declared',cls:d.lang?'ok':'warn',pri:d.lang?'—':'🟡 Medium',tip:d.lang?'Language declared — helps search engines target correct region':'Add lang="en" (or your language code) to the <html> opening tag'},
        {c:'HTML Doctype',v:d.doctype||'Missing',cls:d.doctype==='HTML'?'ok':'warn',pri:'—',tip:'HTML5 doctype ensures correct browser rendering'},
        {c:'Character Encoding (charset)',v:d.charset||'Not declared',cls:d.charset?'ok':'warn',pri:d.charset?'—':'🟢 Low',tip:d.charset?'Charset declared — prevents encoding issues':'Add <meta charset="UTF-8"> to prevent garbled text'},
        {c:'Favicon',v:d.favicon?'✓ Present':' Missing',cls:d.favicon?'ok':'warn',pri:d.favicon?'—':'🟢 Low',tip:d.favicon?'Brand favicon detected':'Add <link rel="icon" href="/favicon.ico"/> for professional branding'},
        {c:'Open Graph (Social)',v:Object.keys(d.openGraph).length+' tags found',cls:Object.keys(d.openGraph).length>=4?'ok':Object.keys(d.openGraph).length>0?'warn':'error',pri:Object.keys(d.openGraph).length>=4?'—':Object.keys(d.openGraph).length>0?'🟡 Medium':'🟡 Medium',tip:Object.keys(d.openGraph).length>=4?'Good OG coverage':'Add og:title, og:description, og:image and og:url'},
        {c:'OG Image',v:d.openGraph['og:image']?'✓ Set':'Missing',cls:d.openGraph['og:image']?'ok':'warn',pri:d.openGraph['og:image']?'—':'🟡 Medium',tip:d.openGraph['og:image']?'Social image set':'Add a 1200×630px og:image meta tag'},
        {c:'Twitter / X Card',v:d.twitter['twitter:card']||'Not set',cls:d.twitter['twitter:card']?'ok':'warn',pri:d.twitter['twitter:card']?'—':'🟢 Low',tip:d.twitter['twitter:card']?'Twitter card active':'Add twitter:card="summary_large_image" for rich tweet previews'},
        {c:'JSON-LD Schema',v:d.structuredData.length>0?d.structuredData.map(s=>s['@type']||'?').join(', '):'None',cls:d.structuredData.length>0?'ok':'warn',pri:d.structuredData.length>0?'—':'🟡 Medium',tip:d.structuredData.length>0?'Structured data active — eligible for rich results':'Add JSON-LD schema to unlock rich snippets in Google'},
        {c:'Hreflang Tags',v:d.hreflangs&&d.hreflangs.length>0?d.hreflangs.length+' found':'None',cls:d.hreflangs&&d.hreflangs.length>0?'ok':'neutral',pri:'—',tip:d.hreflangs&&d.hreflangs.length>0?'International targeting configured':'Add hreflang only if targeting multiple languages/regions'},
      ].map(r=>{
        const ico={ok:'✅',warn:'⚠️',error:'❌',neutral:'ℹ️'};
        return `<tr class="row-${r.cls}">
          <td style="font-weight:700">${r.c}</td>
          <td class="mono" style="font-size:0.78rem;max-width:200px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap" title="${esc(r.v)}">${esc(String(r.v).slice(0,50))}</td>
          <td style="text-align:center;font-size:1.1rem">${ico[r.cls]}</td>
          <td style="font-size:0.75rem">${r.pri}</td>
          <td style="font-size:0.73rem;color:#6b7280;line-height:1.5">${r.tip}</td>
        </tr>`;
      }).join('')}
    </tbody>
  </table>
</div>

<!-- ════════════════════════════
     SECTION 12: CONTENT SUMMARY
════════════════════════════ -->
<div class="section">
  ${secHead('📁','Site Content Summary','Pages, blog posts and content signals detected')}

  <div style="display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-bottom:20px">
    ${[
      {n:d.estimatedPages||0,lbl:'Estimated Pages',icon:'📄',desc:'Non-blog internal links detected',bg:'#eff4ff',brd:'#c7d2fe',col:'#2B5BCD'},
      {n:d.estimatedBlogPosts||0,lbl:'Blog / Posts',icon:'✍️',desc:'URLs matching /blog/ /post/ patterns',bg:'#fffbeb',brd:'#fde68a',col:'#b45309'},
      {n:d.wordCount,lbl:'Word Count',icon:'📖',desc:d.wordCount>=1000?'Long-form — great for SEO':d.wordCount>=300?'Standard length':'Too short — add more content',bg:d.wordCount>=300?'#f0fdf4':'#fffbeb',brd:d.wordCount>=300?'#86efac':'#fde68a',col:d.wordCount>=300?'#166534':'#b45309'},
      {n:d.internalLinks.length,lbl:'Internal Links',icon:'🔗',desc:'PageRank flows through these',bg:'#f0fdf4',brd:'#86efac',col:'#166534'},
      {n:d.externalLinks.length,lbl:'External Links',icon:'🌐',desc:'Links pointing away from site',bg:'#f5f3ff',brd:'#ddd6fe',col:'#5b21b6'},
      {n:d.nofollowLinks.length,lbl:'Nofollow Links',icon:'🚫',desc:'PageRank not transferred',bg:d.nofollowLinks.length>5?'#fffbeb':'#f8faff',brd:d.nofollowLinks.length>5?'#fde68a':'#c7d2fe',col:d.nofollowLinks.length>5?'#b45309':'#2B5BCD'},
    ].map(s=>`
    <div style="background:${s.bg};border:2px solid ${s.brd};border-radius:12px;padding:16px">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
        <span style="font-size:1.2rem">${s.icon}</span>
        <span style="font-size:0.62rem;font-weight:800;text-transform:uppercase;letter-spacing:.5px;color:${s.col}">${s.lbl}</span>
      </div>
      <div style="font-size:1.8rem;font-weight:900;color:${s.col};line-height:1">${s.n.toLocaleString()}</div>
      <div style="font-size:0.72rem;color:#6b7280;margin-top:4px">${s.desc}</div>
    </div>`).join('')}
  </div>
</div>

<!-- ══════════════════════════
     SECTION 13: ACTION PLAN
══════════════════════════ -->
<div class="section">
  ${secHead('🚀','Prioritised Action Plan','Step-by-step roadmap to improve your SEO score')}

  ${[
    ...errors.map((e,i)=>({rank:i+1,pri:'🔴',level:'CRITICAL',bg:'#fff5f5',brd:'#fca5a5',hcol:'#c62828',text:e.text,tip:getFixTip(e.text)})),
    ...warns.map((w,i)=>({rank:errors.length+i+1,pri:'🟡',level:'MEDIUM',bg:'#fffbeb',brd:'#fde68a',hcol:'#b45309',text:w.text,tip:getFixTip(w.text)})),
    ...(errors.length+warns.length===0?[
      {rank:1,pri:'🟢',level:'OPTIMISE',bg:'#f0fdf4',brd:'#86efac',hcol:'#166534',text:'Add more internal links to key pages',tip:'Internal linking distributes PageRank and helps Google discover your content'},
      {rank:2,pri:'🟢',level:'OPTIMISE',bg:'#f0fdf4',brd:'#86efac',hcol:'#166534',text:'Expand content to 1 500+ words for competitive topics',tip:'Longer, comprehensive content typically outranks shorter thin content'},
      {rank:3,pri:'🟢',level:'OPTIMISE',bg:'#f0fdf4',brd:'#86efac',hcol:'#166534',text:'Add FAQ schema markup for featured snippet opportunities',tip:'FAQPage JSON-LD can unlock accordion-style rich results in Google'},
    ]:[]),
  ].slice(0,15).map(item=>`
  <div style="background:${item.bg};border:2px solid ${item.brd};border-radius:12px;padding:16px 18px;margin-bottom:10px;display:flex;gap:14px;align-items:flex-start">
    <div style="width:36px;height:36px;background:linear-gradient(135deg,#2B5BCD,#1e3a8a);border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;font-size:0.82rem;font-weight:900;flex-shrink:0;box-shadow:0 2px 8px rgba(43,91,205,0.3)">${item.rank}</div>
    <div style="flex:1">
      <div style="display:flex;align-items:center;gap:8px;margin-bottom:5px;flex-wrap:wrap">
        <span style="font-size:1rem">${item.pri}</span>
        <span style="font-weight:800;color:#111827;font-size:0.9rem">${esc(item.text)}</span>
        <span style="background:${item.bg};color:${item.hcol};border:1.5px solid ${item.brd};font-size:0.6rem;font-weight:800;padding:2px 9px;border-radius:20px">${item.level}</span>
      </div>
      <div style="font-size:0.78rem;color:#374151;line-height:1.6;padding-left:2px">
        <strong style="color:${item.hcol}">💡 How to fix:</strong> ${esc(item.tip)}
      </div>
    </div>
  </div>`).join('')}
</div>

<!-- ═════════════
     FOOTER
═════════════ -->
<!-- ══════ FOOTER — WHITE THEME ══════ -->
<div style="background:#fff;border-top:4px solid #3B5DD4">
  <!-- orange + blue accent stripe -->
  <div style="height:4px;background:linear-gradient(90deg,#3B5DD4,#F97316,#FEB622,#F97316,#3B5DD4)"></div>

  <div style="padding:30px 44px;display:flex;align-items:center;justify-content:space-between;gap:24px;flex-wrap:wrap">

    <!-- Logo + brand -->
    <div style="display:flex;align-items:center;gap:18px">
      <img src="https://7thclub.com/wp-content/uploads/2025/02/Logo.png"
        style="height:56px;object-fit:contain"
        alt="7th Club"
        onerror="this.outerHTML='<span style=font-size:1.6rem;font-weight:900;color:#3B5DD4;letter-spacing:1px>7THCLUB</span>'"/>
      <div style="border-left:2px solid #dbeafe;padding-left:16px">
        <div style="font-size:0.78rem;font-weight:800;color:#1e3a8a;text-transform:uppercase;letter-spacing:1.5px">SEO Analyzer Pro</div>
        <div style="font-size:0.68rem;color:#6b7280;margin-top:3px">Powered by 7th Club</div>
        <a href="https://7thclub.com" target="_blank"
          style="display:inline-flex;align-items:center;gap:5px;background:#F97316;color:#fff;font-size:0.68rem;font-weight:800;padding:5px 12px;border-radius:6px;text-decoration:none;margin-top:8px">
          🏆 Visit 7thclub.com
        </a>
      </div>
    </div>

    <!-- Score box -->
    <div style="background:#fff;border:2px solid #3B5DD4;border-radius:14px;padding:16px 28px;text-align:center;box-shadow:0 4px 16px rgba(59,93,212,0.1)">
      <div style="font-size:0.6rem;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px">Overall SEO Score</div>
      <div style="font-size:2.6rem;font-weight:900;color:${scoreCol};line-height:1">${score}</div>
      <div style="font-size:0.6rem;color:#9ca3af">out of 100</div>
      <div style="font-size:0.82rem;font-weight:800;color:${scoreCol};margin-top:5px">${scoreLbl}</div>
    </div>

    <!-- Date + URL -->
    <div style="text-align:right">
      <div style="background:#f0f4ff;border:2px solid #3B5DD4;border-radius:10px;padding:10px 18px;margin-bottom:10px;display:inline-block">
        <div style="font-size:0.6rem;font-weight:700;color:#6b7280;text-transform:uppercase;letter-spacing:.5px">Report Generated</div>
        <div style="font-size:0.95rem;font-weight:900;color:#1e3a8a;margin-top:2px">${now}</div>
        <div style="font-size:0.72rem;font-weight:700;color:#3B5DD4;margin-top:1px">${nowTime}</div>
      </div>
      <div style="font-size:0.7rem;color:#6b7280;max-width:300px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:right">
        <a href="${esc(d.url||'#')}" target="_blank" style="color:#3B5DD4;font-weight:600">${esc(d.url||'')}</a>
      </div>
      <div style="font-size:0.6rem;color:#9ca3af;margin-top:5px">Report by 7th Club SEO Analyzer Pro</div>
    </div>

  </div>
</div>

</div><!-- .page -->
</body>
</html>`;

  const blob=new Blob([html],{type:'text/html;charset=utf-8;'});
  const a=document.createElement('a');
  a.href=URL.createObjectURL(blob);
  a.download='7thclub-audit-'+( d.host||'site')+'.html';
  a.click();
}

/* ─── TOOL URLs ─── */
function injectToolUrls(host){
  const enc=encodeURIComponent(host),raw=host;
  const tools={'tool-ahrefs-site':'https://ahrefs.com/site-explorer/overview/v2/subdomains/live?target='+raw,'tool-ahrefs-kw':'https://ahrefs.com/keywords-explorer/google/global?input='+enc,'tool-moz':'https://moz.com/link-explorer/overview?site='+raw,'tool-majestic':'https://majestic.com/reports/site-explorer?oq='+raw,'tool-semrush':'https://www.semrush.com/analytics/overview/?target='+raw+'&searchType=domain','tool-similarweb':'https://www.similarweb.com/website/'+raw+'/','tool-ubersuggest':'https://app.neilpatel.com/en/ubersuggest/?locator=domain_overview&domain='+raw,'tool-serpstat':'https://serpstat.com/en/links/report/'+raw+'/?se=g_us','tool-pagespeed':'https://pagespeed.web.dev/report?url=https%3A%2F%2F'+enc,'tool-gtmetrix':'https://gtmetrix.com/?url=https%3A%2F%2F'+raw,'tool-schemaval':'https://search.google.com/test/rich-results?url=https%3A%2F%2F'+enc,'tool-siteliner':'https://www.siteliner.com/link?_=https://'+raw,'tool-copyscape':'https://www.copyscape.com/?q=https://'+raw};
  Object.entries(tools).forEach(function([id,href]){const el=document.getElementById(id);if(el)el.href=href;});
}

/* ─── MAIN ANALYZE ─── */
window.analyze=async function(){
  $('loadingScreen').style.display='';
  $('errorScreen').classList.add('hidden');
  document.querySelectorAll('.panel').forEach(p=>p.classList.add('hidden'));
  $('scoreNum').textContent='--'; $('scoreNum').style.color='';
  $('scProg').style.strokeDashoffset='207.3';
  $('issuesBanner').classList.add('hidden');
  $('fixesBlock').classList.add('hidden');
  _seoData=null;
  if($('saTotalPages'))$('saTotalPages').textContent='—';
  if($('saBlogPosts'))$('saBlogPosts').textContent='—';
  if($('saExtLinks'))$('saExtLinks').textContent='—';
  if($('saTechScore'))$('saTechScore').textContent='—';

  try{
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab)throw new Error('No active tab');

    try{
      const url=new URL(tab.url);
      $('urlProto').textContent=url.protocol.replace(':','');
      $('urlHost').textContent=url.hostname;
      $('urlPath').textContent=url.pathname.length>30?url.pathname.substring(0,30)+'…':url.pathname;
      $('urlProto').style.color=url.protocol==='https:'?'#2B5BCD':'#ef4444';
      $('httpsBadge').textContent=url.protocol==='https:'?'🔒':'⚠️';
    }catch(e){$('urlHost').textContent=tab.url||'';}

    let result;
    try{
      [result]=await chrome.scripting.executeScript({
        target:{tabId:tab.id},
        func:()=>{
          const d={};
          const metas={};
          document.querySelectorAll('meta').forEach(m=>{const n=m.getAttribute('name')||m.getAttribute('property')||m.getAttribute('http-equiv');const c=m.getAttribute('content');if(n&&c!==null)metas[n.toLowerCase()]=c;});
          d.url=location.href; d.host=location.hostname; d.isHttps=location.protocol==='https:';
          d.metas=metas; d.titleTag=document.querySelector('title')?.textContent?.trim()||'';
          d.description=metas['description']||''; d.keywords=metas['keywords']||'';
          d.robots=metas['robots']||metas['googlebot']||''; d.viewport=metas['viewport']||'';
          d.author=metas['author']||''; d.canonical=document.querySelector('link[rel="canonical"]')?.href||'';
          d.lang=document.documentElement.lang||''; d.charset=document.characterSet||'';
          d.doctype=document.doctype?.name?.toUpperCase()||'Missing';
          d.favicon=document.querySelector('link[rel~="icon"]')?.href||'';
          const og={},tw={};
          Object.entries(metas).forEach(([k,v])=>{if(k.startsWith('og:'))og[k]=v;if(k.startsWith('twitter:'))tw[k]=v;});
          d.openGraph=og; d.twitter=tw;
          const headings=[];
          document.querySelectorAll('h1,h2,h3,h4,h5,h6').forEach(h=>headings.push({level:+h.tagName[1],text:h.textContent.trim().slice(0,150)}));
          d.headings=headings; d.h1Count=headings.filter(h=>h.level===1).length;
          const origin=location.origin;
          const links=[];
          document.querySelectorAll('a[href]').forEach(a=>{
            const href=a.href||'';
            if(!href||href.startsWith('javascript:')||href.startsWith('mailto:')||href.startsWith('tel:'))return;
            const rel=a.getAttribute('rel')||'';
            const isExternal=href.startsWith('http')&&!href.startsWith(origin);
            links.push({href,text:a.textContent.trim().slice(0,80),rel,isExternal,nofollow:rel.includes('nofollow'),sponsored:rel.includes('sponsored'),ugc:rel.includes('ugc'),newTab:a.target==='_blank'});
          });
          d.links=links; d.internalLinks=links.filter(l=>!l.isExternal); d.externalLinks=links.filter(l=>l.isExternal); d.nofollowLinks=links.filter(l=>l.nofollow);
          const images=[];
          document.querySelectorAll('img').forEach(img=>{images.push({src:img.src,alt:img.getAttribute('alt'),hasAlt:img.hasAttribute('alt'),altEmpty:img.getAttribute('alt')==='',width:img.naturalWidth,height:img.naturalHeight,loading:img.getAttribute('loading'),srcset:!!img.getAttribute('srcset')});});
          d.images=images; d.imagesWithAlt=images.filter(i=>i.hasAlt&&!i.altEmpty).length; d.imagesMissing=images.filter(i=>!i.hasAlt||i.altEmpty).length; d.imagesLazy=images.filter(i=>i.loading==='lazy').length;
          const schemas=[];
          document.querySelectorAll('script[type="application/ld+json"]').forEach(s=>{try{schemas.push(JSON.parse(s.textContent))}catch(e){}});
          d.structuredData=schemas;
          const hreflangs=[];
          document.querySelectorAll('link[hreflang]').forEach(l=>hreflangs.push({lang:l.hreflang,href:l.href}));
          d.hreflangs=hreflangs;
          const robotsLc=(d.robots||'').toLowerCase();
          d.isNoindex=robotsLc.includes('noindex'); d.isNofollow=robotsLc.includes('nofollow');
          d.wordCount=(document.body?.innerText||'').trim().split(/\s+/).filter(Boolean).length;
          d.bodyText=(document.body?.innerText||'').trim();
          d.scriptCount=document.querySelectorAll('script').length;
          d.styleCount=document.querySelectorAll('link[rel="stylesheet"]').length;
          // Blog detection
          const blogPatterns=[/\/blog\//i,/\/post\//i,/\/article\//i,/\/news\//i,/\/\d{4}\/\d{2}\//,/\?p=\d+/,/\/stories\//i,/\/updates\//i];
          const internalHrefs=[...new Set(links.filter(l=>!l.isExternal).map(l=>l.href))];
          const blogLinks=internalHrefs.filter(h=>blogPatterns.some(p=>p.test(h)));
          const pageLinks=internalHrefs.filter(h=>!blogPatterns.some(p=>p.test(h)));
          d.estimatedBlogPosts=blogLinks.length; d.estimatedPages=pageLinks.length;
          d.blogPostUrls=blogLinks.slice(0,200); d.pageUrls=pageLinks.slice(0,200);
          // Performance
          if(window.performance?.getEntriesByType){
            const nav=performance.getEntriesByType('navigation')[0];
            if(nav){d.domContentLoaded=Math.round(nav.domContentLoadedEventEnd);d.loadTime=Math.round(nav.loadEventEnd);d.ttfb=Math.round(nav.responseStart-nav.requestStart);}
          }
          return d;
        }
      });
    }catch(e){
      $('loadingScreen').style.display='none';
      $('errorScreen').classList.remove('hidden');
      return;
    }

    const seo=result.result;
    const {score,issues}=calcScore(seo);

    $('loadingScreen').style.display='none';
    $('tab-overview').classList.remove('hidden');

    setTimeout(()=>animateScore(score),150);
    renderOverview(seo,score,issues);
    renderSERP(seo);
    renderMeta(seo);
    renderHeadings(seo);
    renderLinks(seo);
    renderImages(seo);
    renderTechnical(seo);
    renderSiteAudit(seo);
    renderIndexedPages(seo);
    renderPageSpeed(seo);
    renderInternalLinks(seo);

    // ── Update branded header ──
    const hdrDom=$('hdrDomain');
    if(hdrDom)hdrDom.textContent=seo.host||'';
    const hdrRing=$('hdrScoreRing');
    if(hdrRing){
      hdrRing.style.display='flex';
      const prog=document.getElementById('hdrRingProg');
      const val=$('hdrScoreVal');
      if(prog){const circ=113,offset=circ-(score/100)*circ,col=score>=80?'#3B5DD4':score>=60?'#FEB622':'#ef4444';prog.style.stroke=col;prog.style.strokeDashoffset=offset;}
      if(val){val.textContent=score;val.style.color=score>=80?'#93c5fd':score>=60?'#FEB622':'#fca5a5';}
    }

  }catch(err){
    $('loadingScreen').style.display='none';
    $('errorScreen').classList.remove('hidden');
    console.error('[7th Club SEO Pro]',err);
  }
};

/* ─── INIT ─── */
document.addEventListener('DOMContentLoaded',function(){
  // Tab switching
  const tabNav=document.getElementById('tabNav');
  if(tabNav){
    tabNav.addEventListener('click',function(e){
      const btn=e.target.closest('.hn-btn');
      if(!btn)return;
      document.querySelectorAll('.hn-btn').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      document.querySelectorAll('.panel').forEach(p=>p.classList.add('hidden'));
      const panel=document.getElementById('tab-'+btn.dataset.tab);
      if(panel)panel.classList.remove('hidden');
    });
  }

  function runAnalyze(){
    window.analyze().then(function(){
      try{
        chrome.tabs.query({active:true,currentWindow:true},function(tabs){
          if(tabs&&tabs[0]&&tabs[0].url){
            try{injectToolUrls(new URL(tabs[0].url).hostname);}catch(e){}
          }
        });
      }catch(e){}
    }).catch(function(){});
  }

  // Auto-analyze on open
  runAnalyze();

  const dlBtn=$('btnDownload'); if(dlBtn)dlBtn.addEventListener('click',downloadReport);
  const auditBtn=$('btnAuditReport'); if(auditBtn)auditBtn.addEventListener('click',generateAuditReport);
  const auditBtn2=$('btnAuditReport2'); if(auditBtn2)auditBtn2.addEventListener('click',generateAuditReport);
  document.getElementById('btnAnalyze').addEventListener('click',runAnalyze);
});
