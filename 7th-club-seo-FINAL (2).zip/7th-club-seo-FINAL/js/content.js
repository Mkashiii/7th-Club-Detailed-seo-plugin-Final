// 7th Club SEO Analyzer Pro — Content Script v2
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'getSEOData') {
    try {
      sendResponse({ success: true, data: collectAll() });
    } catch(e) {
      sendResponse({ success: false, error: e.message });
    }
  }
  return true;
});

function collectAll() {
  const d = {};
  const metas = {};
  document.querySelectorAll('meta').forEach(m => {
    const n = m.getAttribute('name') || m.getAttribute('property') || m.getAttribute('http-equiv');
    const c = m.getAttribute('content');
    if (n && c !== null) metas[n.toLowerCase()] = c;
  });

  d.url        = location.href;
  d.host       = location.hostname;
  d.protocol   = location.protocol;
  d.isHttps    = location.protocol === 'https:';
  d.metas      = metas;
  d.titleTag   = (document.querySelector('title') || {}).textContent?.trim() || '';
  d.description = metas['description'] || '';
  d.keywords   = metas['keywords'] || '';
  d.robots     = metas['robots'] || metas['googlebot'] || '';
  d.viewport   = metas['viewport'] || '';
  d.author     = metas['author'] || '';
  d.canonical  = (document.querySelector('link[rel="canonical"]') || {}).href || '';
  d.lang       = document.documentElement.lang || '';
  d.charset    = document.characterSet || 'UTF-8';
  d.doctype    = document.doctype?.name?.toUpperCase() || 'Missing';

  // OG / Twitter
  const og = {}, tw = {};
  Object.entries(metas).forEach(([k,v]) => {
    if (k.startsWith('og:')) og[k] = v;
    if (k.startsWith('twitter:')) tw[k] = v;
  });
  d.openGraph = og;
  d.twitter   = tw;

  // Headings
  const headings = [];
  document.querySelectorAll('h1,h2,h3,h4,h5,h6').forEach(h => {
    headings.push({ level: +h.tagName[1], text: h.textContent.trim().slice(0,150) });
  });
  d.headings = headings;
  d.h1Count  = headings.filter(h=>h.level===1).length;

  // Links
  const origin = location.origin;
  const links  = [];
  document.querySelectorAll('a[href]').forEach(a => {
    const href = a.href || '';
    if (!href || href.startsWith('javascript:') || href.startsWith('mailto:') || href.startsWith('tel:')) return;
    const rel = a.getAttribute('rel') || '';
    const isExt = href.startsWith('http') && !href.startsWith(origin);
    links.push({
      href, text: a.textContent.trim().slice(0,80),
      rel, isExternal: isExt,
      nofollow: rel.includes('nofollow'),
      sponsored: rel.includes('sponsored'),
      ugc: rel.includes('ugc'),
      newTab: a.target === '_blank',
      hasTitle: !!a.title
    });
  });
  d.links         = links;
  d.internalLinks = links.filter(l=>!l.isExternal);
  d.externalLinks = links.filter(l=>l.isExternal);
  d.nofollowLinks = links.filter(l=>l.nofollow);
  d.brokenAnchors = links.filter(l=>l.href==='#' || l.href===location.href+'#').length;

  // Images
  const images = [];
  document.querySelectorAll('img').forEach(img => {
    images.push({
      src: img.src, alt: img.getAttribute('alt'),
      hasAlt: img.hasAttribute('alt'), altEmpty: img.getAttribute('alt')==='',
      width: img.naturalWidth, height: img.naturalHeight,
      loading: img.getAttribute('loading'),
      decoding: img.getAttribute('decoding'),
      srcset: !!img.getAttribute('srcset'),
      title: img.getAttribute('title') || ''
    });
  });
  d.images          = images;
  d.imagesWithAlt   = images.filter(i=>i.hasAlt&&!i.altEmpty).length;
  d.imagesMissing   = images.filter(i=>!i.hasAlt||i.altEmpty).length;
  d.imagesLazy      = images.filter(i=>i.loading==='lazy').length;
  d.imagesResponsive= images.filter(i=>i.srcset).length;

  // Structured Data
  const schemas = [];
  document.querySelectorAll('script[type="application/ld+json"]').forEach(s => {
    try { schemas.push(JSON.parse(s.textContent)); } catch(e) {}
  });
  d.structuredData = schemas;

  // Performance / page signals
  const bodyText = document.body?.innerText || '';
  d.wordCount    = bodyText.trim().split(/\s+/).filter(Boolean).length;
  d.hasLazyImgs  = d.imagesLazy > 0;

  // Scripts / styles count
  d.scriptCount  = document.querySelectorAll('script').length;
  d.styleCount   = document.querySelectorAll('link[rel="stylesheet"]').length;
  d.inlineStyles = document.querySelectorAll('[style]').length;

  // Socials
  d.hasFacebook  = !!(metas['og:type'] || og['og:url']);
  d.hasTwitterCard = !!(tw['twitter:card']);

  // Favicon
  const favicon = document.querySelector('link[rel~="icon"]');
  d.favicon = favicon ? favicon.href : '';

  // hreflang
  const hreflangs = [];
  document.querySelectorAll('link[hreflang]').forEach(l => {
    hreflangs.push({ lang: l.hreflang, href: l.href });
  });
  d.hreflangs = hreflangs;

  // noindex detection
  const robotsContent = (d.robots || '').toLowerCase();
  d.isNoindex  = robotsContent.includes('noindex');
  d.isNofollow = robotsContent.includes('nofollow');

  // Timing (if available)
  if (window.performance && performance.timing) {
    const t = performance.timing;
    if (t.loadEventEnd && t.navigationStart) {
      d.loadTime = t.loadEventEnd - t.navigationStart;
    }
  }
  if (window.performance?.getEntriesByType) {
    const nav = performance.getEntriesByType('navigation')[0];
    if (nav) {
      d.domContentLoaded = Math.round(nav.domContentLoadedEventEnd);
      d.loadTime         = Math.round(nav.loadEventEnd);
      d.ttfb             = Math.round(nav.responseStart - nav.requestStart);
    }
  }

  return d;
}
